import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

/** Followers (people who follow `userId`) */
export const useFollowers = (userId?: string) =>
  useQuery({
    queryKey: ["followers", userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("follows")
        .select("follower_id, profiles:profiles!follows_follower_id_fkey1(id, uid, in_game_name, avatar_url, level_name)")
        .eq("following_id", userId);
      if (error) {
        // Fallback: two-step fetch (no FK alias available)
        const { data: rows } = await supabase.from("follows").select("follower_id").eq("following_id", userId);
        const ids = (rows || []).map((r: any) => r.follower_id);
        if (!ids.length) return [];
        const { data: profs } = await supabase.from("profiles").select("id, uid, in_game_name, avatar_url, level_name").in("id", ids);
        return profs || [];
      }
      return (data || []).map((d: any) => d.profiles).filter(Boolean);
    },
    enabled: !!userId,
  });

/** People `userId` is following */
export const useFollowing = (userId?: string) =>
  useQuery({
    queryKey: ["following", userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data: rows } = await supabase
        .from("follows")
        .select("following_id")
        .eq("follower_id", userId);
      const ids = (rows || []).map((r: any) => r.following_id);
      if (!ids.length) return [];
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, uid, in_game_name, avatar_url, level_name")
        .in("id", ids);
      return profs || [];
    },
    enabled: !!userId,
  });

/** Counts */
export const useFollowCounts = (userId?: string) =>
  useQuery({
    queryKey: ["followCounts", userId],
    queryFn: async () => {
      if (!userId) return { followers: 0, following: 0 };
      const [{ count: followers }, { count: following }] = await Promise.all([
        supabase.from("follows").select("*", { count: "exact", head: true }).eq("following_id", userId),
        supabase.from("follows").select("*", { count: "exact", head: true }).eq("follower_id", userId),
      ]);
      return { followers: followers || 0, following: following || 0 };
    },
    enabled: !!userId,
  });

/** Relationship of current user → target user */
export const useFollowStatus = (targetId?: string) => {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["followStatus", user?.id, targetId],
    queryFn: async () => {
      if (!user || !targetId || user.id === targetId)
        return { isFollowing: false, hasPending: false, theyFollowMe: false };
      const [{ data: f }, { data: req }, { data: tf }] = await Promise.all([
        supabase.from("follows").select("id").eq("follower_id", user.id).eq("following_id", targetId).maybeSingle(),
        supabase.from("follow_requests").select("id").eq("requester_id", user.id).eq("target_id", targetId).eq("status", "pending").maybeSingle(),
        supabase.from("follows").select("id").eq("follower_id", targetId).eq("following_id", user.id).maybeSingle(),
      ]);
      return { isFollowing: !!f, hasPending: !!req, theyFollowMe: !!tf };
    },
    enabled: !!user && !!targetId,
  });
};

/** Pending incoming follow requests for current user */
export const useIncomingFollowRequests = () => {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["incomingFollowRequests", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data: rows } = await supabase
        .from("follow_requests")
        .select("id, requester_id, created_at")
        .eq("target_id", user.id)
        .eq("status", "pending")
        .order("created_at", { ascending: false });
      const ids = (rows || []).map((r: any) => r.requester_id);
      if (!ids.length) return [];
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, uid, in_game_name, avatar_url, level_name")
        .in("id", ids);
      return (rows || []).map((r: any) => ({
        request_id: r.id,
        ...((profs || []).find((p: any) => p.id === r.requester_id) || {}),
      }));
    },
    enabled: !!user,
  });
};

export const useSendFollowRequest = () => {
  const { user } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (targetId: string) => {
      if (!user) throw new Error("Not authenticated");
      const { error } = await supabase.from("follow_requests").insert({
        requester_id: user.id,
        target_id: targetId,
        status: "pending",
      });
      if (error) throw error;
    },
    onSuccess: (_, targetId) => {
      toast.success("Follow request sent");
      qc.invalidateQueries({ queryKey: ["followStatus", user?.id, targetId] });
    },
    onError: (e: any) => toast.error(e.message || "Failed to send request"),
  });
};

export const useCancelFollowRequest = () => {
  const { user } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (targetId: string) => {
      if (!user) throw new Error("Not authenticated");
      const { error } = await supabase
        .from("follow_requests")
        .delete()
        .eq("requester_id", user.id)
        .eq("target_id", targetId)
        .eq("status", "pending");
      if (error) throw error;
    },
    onSuccess: (_, targetId) => {
      toast.success("Request cancelled");
      qc.invalidateQueries({ queryKey: ["followStatus", user?.id, targetId] });
    },
  });
};

export const useUnfollow = () => {
  const { user } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (targetId: string) => {
      if (!user) throw new Error("Not authenticated");
      const { error } = await supabase
        .from("follows")
        .delete()
        .eq("follower_id", user.id)
        .eq("following_id", targetId);
      if (error) throw error;
    },
    onSuccess: (_, targetId) => {
      toast.success("Unfollowed");
      qc.invalidateQueries({ queryKey: ["followStatus", user?.id, targetId] });
      qc.invalidateQueries({ queryKey: ["followCounts"] });
      qc.invalidateQueries({ queryKey: ["following", user?.id] });
    },
  });
};

export const useRespondFollowRequest = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ requestId, accept }: { requestId: string; accept: boolean }) => {
      const { error } = await supabase
        .from("follow_requests")
        .update({ status: accept ? "accepted" : "rejected" })
        .eq("id", requestId);
      if (error) throw error;
    },
    onSuccess: (_, vars) => {
      toast.success(vars.accept ? "Request accepted" : "Request rejected");
      qc.invalidateQueries({ queryKey: ["incomingFollowRequests"] });
      qc.invalidateQueries({ queryKey: ["followers"] });
      qc.invalidateQueries({ queryKey: ["followCounts"] });
    },
    onError: (e: any) => toast.error(e.message || "Failed"),
  });
};