import { useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

export const useDailyLogin = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const hasRun = useRef(false);

  useEffect(() => {
    if (!user || hasRun.current) return;
    hasRun.current = true;

    const doLogin = async () => {
      try {
        const { data: before } = await supabase
          .from("profiles")
          .select("level, level_name")
          .eq("id", user.id)
          .single();

        const { data: recorded } = await supabase.rpc("record_daily_login", {
          _user_id: user.id,
        });

        if (recorded) {
          toast.success("Daily Login Bonus! +5 XP 🎯");
          await queryClient.invalidateQueries({ queryKey: ["profile"] });

          const { data: after } = await supabase
            .from("profiles")
            .select("level, level_name")
            .eq("id", user.id)
            .single();

          if (after && before && after.level > before.level) {
            setTimeout(() => {
              toast.success(
                `🏆 Congratulations! You reached Level ${after.level} — ${after.level_name}!`,
                { duration: 6000 }
              );
            }, 800);
          }
        }
      } catch (_) {
        // Silent fail — daily login is non-critical
      }
    };

    doLogin();
  }, [user, queryClient]);
};
