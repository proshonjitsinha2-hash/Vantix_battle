import { Calendar, Users, Trophy, Lock, DollarSign } from "lucide-react";

export interface Match {
  id: string;
  name: string;
  type: "Bermuda" | "1v1";
  dateTime: string;
  entryFee: number;
  prizePool: number;
  matchId?: string;
  password?: string;
  maxPlayers: number;
  joinedPlayers: number;
  status: "upcoming" | "ongoing";
}

interface MatchCardProps {
  match: Match;
  onJoin: (matchId: string) => void;
}

const MatchCard = ({ match, onJoin }: MatchCardProps) => {
  const isUpcoming = match.status === "upcoming";
  const isFull = match.joinedPlayers >= match.maxPlayers;

  return (
    <div className={`relative rounded-xl bg-card p-4 ${isUpcoming ? "card-upcoming" : "card-ongoing"}`}>
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-display font-bold text-lg text-foreground">{match.name}</h3>
          <span className={`text-xs font-bold px-2 py-1 rounded-full font-display ${isUpcoming ? "bg-success/20 text-success" : "bg-destructive/20 text-destructive"}`}>
            {isUpcoming ? "UPCOMING" : "ONGOING"}
          </span>
        </div>

        <div className="space-y-2 text-sm font-body">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar size={14} />
            <span>{new Date(match.dateTime).toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-muted-foreground">
              <DollarSign size={14} />
              <span>Entry: ₹{match.entryFee}</span>
            </div>
            <div className="flex items-center gap-2 text-primary">
              <Trophy size={14} />
              <span className="font-bold">₹{match.prizePool}</span>
            </div>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users size={14} />
            <span>{match.joinedPlayers}/{match.maxPlayers} Players</span>
          </div>
          {match.matchId && (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Lock size={14} />
              <span>ID: {match.matchId} | Pass: {match.password}</span>
            </div>
          )}
        </div>

        <div className="mt-3 flex gap-2">
          {match.joinedPlayers < match.maxPlayers && isUpcoming && (
            <button
              onClick={() => onJoin(match.id)}
              className="flex-1 rounded-lg bg-primary py-2 font-display font-bold text-sm text-primary-foreground tracking-wider hover:opacity-90 transition-opacity"
            >
              JOIN - ₹{match.entryFee}
            </button>
          )}
          {isFull && (
            <span className="flex-1 text-center rounded-lg bg-muted py-2 font-display font-bold text-sm text-muted-foreground">FULL</span>
          )}
        </div>
      </div>
    </div>
  );
};

export default MatchCard;
