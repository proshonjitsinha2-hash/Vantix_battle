import { useState } from "react";
import { Gift, Copy, Share2, Check, Users } from "lucide-react";
import { motion } from "framer-motion";
import { useProfile } from "@/hooks/useProfile";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

const ReferEarnCard = () => {
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const [copied, setCopied] = useState(false);

  const { data: referralCount = 0 } = useQuery({
    queryKey: ["referral_count", user?.id],
    queryFn: async () => {
      const { count, error } = await supabase
        .from("referrals")
        .select("*", { count: "exact", head: true })
        .eq("referrer_id", user!.id);
      if (error) return 0;
      return count ?? 0;
    },
    enabled: !!user,
  });

  const referralCode = profile?.referral_code || "";

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(referralCode);
      setCopied(true);
      toast.success("Referral code copied!");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Failed to copy");
    }
  };

  const handleShare = async () => {
    const shareUrl = `${window.location.origin}?ref=${referralCode}`;
    const shareText = `🎮 Vantix Battle - Join Now!\n\nUse my referral code: ${referralCode}\n💰 Get ₹10 bonus on signup!\n\n${shareUrl}`;

    try {
      if (navigator.share && navigator.canShare) {
        await navigator.share({
          title: "Vantix Battle - Join Now!",
          text: `Use my referral code ${referralCode} to get ₹10 bonus on signup! 🎮🔥`,
          url: shareUrl,
        });
        toast.success("Shared successfully!");
      } else {
        await navigator.clipboard.writeText(shareText);
        toast.success("Share link copied! Paste it in WhatsApp, Instagram, etc.");
      }
    } catch (error: unknown) {
      // User cancelled or share failed - try clipboard fallback
      if (error instanceof Error && error.name !== "AbortError") {
        try {
          await navigator.clipboard.writeText(shareText);
          toast.success("Link copied! Share it on WhatsApp, Instagram, etc.");
        } catch {
          toast.error("Could not share. Please copy the code manually.");
        }
      }
    }
  };

  if (!profile) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        {/* Header with gradient accent */}
        <div className="relative px-4 pt-4 pb-3">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-orange-400 to-yellow-400" />
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Gift size={22} className="text-primary" />
            </div>
            <div>
              <h3 className="font-display font-bold text-foreground text-base">REFER & EARN</h3>
              <p className="text-xs text-muted-foreground font-body">
                Apne friends ko invite karo aur reward pao
              </p>
            </div>
          </div>
        </div>

        {/* Referral Code */}
        <div className="px-4 pb-3">
          <div className="flex items-center gap-2 rounded-lg bg-background border border-border p-2.5">
            <div className="flex-1 text-center">
              <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">Your Code</p>
              <p className="font-display font-bold text-lg text-primary tracking-widest">{referralCode}</p>
            </div>
            <button
              onClick={handleCopy}
              className="p-2.5 rounded-lg bg-muted hover:bg-accent transition-colors"
            >
              {copied ? <Check size={18} className="text-green-400" /> : <Copy size={18} className="text-muted-foreground" />}
            </button>
          </div>
        </div>

        {/* Stats + Actions */}
        <div className="px-4 pb-4 flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-body">
            <Users size={14} />
            <span>{referralCount} referral{referralCount !== 1 ? "s" : ""}</span>
          </div>
          <button
            onClick={handleShare}
            className="ml-auto flex items-center gap-2 px-4 py-2.5 rounded-lg bg-primary font-display font-bold text-sm text-primary-foreground hover:opacity-90 transition-opacity"
          >
            <Share2 size={16} />
            INVITE NOW
          </button>
        </div>

        {/* Reward info */}
        <div className="px-4 pb-4">
          <div className="rounded-lg bg-muted/50 p-3 space-y-1">
            <p className="text-xs font-body text-muted-foreground">
              🎁 <span className="text-foreground font-semibold">You get:</span> ₹10 + 40 XP per referral
            </p>
            <p className="text-xs font-body text-muted-foreground">
              🎉 <span className="text-foreground font-semibold">Friend gets:</span> ₹10 signup bonus
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default ReferEarnCard;
