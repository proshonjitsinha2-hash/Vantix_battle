import {
  getLevelInfo,
  getLevelColor,
  getLevelBorderColor,
  getLevelBarColor,
  getLevelEmoji,
} from "@/utils/levelSystem";

interface LevelProgressCardProps {
  xp: number;
  level: number;
  levelName: string;
}

export const LevelProgressCard = ({ xp, level, levelName }: LevelProgressCardProps) => {
  const { next, progress, progressXP, neededXP } = getLevelInfo(xp);

  return (
    <div className="rounded-xl bg-card p-4 border border-border">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <span className="text-2xl">{getLevelEmoji(levelName)}</span>
          <div>
            <p className={`font-display font-bold text-lg leading-none ${getLevelColor(levelName)}`}>
              {levelName}
            </p>
            <p className="text-xs text-muted-foreground font-body mt-0.5">Level {level}</p>
          </div>
        </div>
        <div
          className={`px-3 py-1.5 rounded-full border text-xs font-display font-bold ${getLevelBorderColor(levelName)} ${getLevelColor(levelName)}`}
        >
          {xp} XP
        </div>
      </div>

      <div className="relative h-2.5 w-full overflow-hidden rounded-full bg-secondary mb-2">
        <div
          className="h-full rounded-full transition-all duration-700 ease-out"
          style={{ width: `${progress}%`, backgroundColor: getLevelBarColor(levelName) }}
        />
      </div>

      {next ? (
        <div className="flex justify-between text-xs text-muted-foreground font-body">
          <span>{progressXP} / {neededXP} XP</span>
          <span>Next: {getLevelEmoji(next.name)} {next.name} ({next.minXP} XP)</span>
        </div>
      ) : (
        <p className="text-xs text-center font-display font-bold text-yellow-500">
          👑 MAX RANK ACHIEVED
        </p>
      )}
    </div>
  );
};
