import { useState } from "react";
import { Edit2, Check, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

interface BioSectionProps {
  userId: string;
  currentBio: string | null;
  isOwner: boolean;
}

export const BioSection = ({ userId, currentBio, isOwner }: BioSectionProps) => {
  const [editing, setEditing] = useState(false);
  const [bio, setBio] = useState(currentBio ?? "");
  const [saving, setSaving] = useState(false);
  const queryClient = useQueryClient();

  const handleSave = async () => {
    if (!isOwner) return;
    setSaving(true);
    try {
      await supabase.from("profiles").update({ bio }).eq("id", userId);
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      toast.success("Bio updated!");
      setEditing(false);
    } catch {
      toast.error("Failed to update bio");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="rounded-xl bg-card p-4 border border-border">
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-display font-bold text-foreground">BIO</h3>
        {isOwner && !editing && (
          <button
            onClick={() => setEditing(true)}
            className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground"
          >
            <Edit2 size={14} />
          </button>
        )}
      </div>
      {editing ? (
        <div className="space-y-2">
          <textarea
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            maxLength={150}
            placeholder="Write something about yourself..."
            className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground font-body placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none min-h-[70px]"
          />
          <div className="flex gap-2 justify-end">
            <button
              onClick={() => { setEditing(false); setBio(currentBio ?? ""); }}
              className="p-2 rounded-lg hover:bg-muted text-muted-foreground"
            >
              <X size={16} />
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="p-2 rounded-lg bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50"
            >
              <Check size={16} />
            </button>
          </div>
        </div>
      ) : (
        <p className="text-sm text-muted-foreground font-body">
          {currentBio || "No bio yet..."}
        </p>
      )}
    </div>
  );
};
