import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

const ImageSlider = () => {
  const [current, setCurrent] = useState(0);

  const { data: images = [] } = useQuery({
    queryKey: ["slider_images"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("slider_images")
        .select("*")
        .order("sort_order");
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    if (images.length <= 1) return;
    const interval = setInterval(() => {
      setCurrent((c) => (c + 1) % images.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [images.length]);

  if (images.length === 0) {
    return (
      <div className="w-full aspect-video rounded-xl bg-card border border-border flex items-center justify-center">
        <p className="text-muted-foreground font-body text-sm">No banners yet</p>
      </div>
    );
  }

  return (
    <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-card">
      {images.map((img, i) => (
        <a
          key={img.id}
          href={img.redirect_link || "#"}
          target="_blank"
          rel="noopener noreferrer"
          className={`absolute inset-0 transition-opacity duration-500 ${i === current ? "opacity-100" : "opacity-0 pointer-events-none"}`}
        >
          <img src={img.image_url} alt="" className="w-full h-full object-cover" />
        </a>
      ))}
      {images.length > 1 && (
        <>
          <button onClick={() => setCurrent((c) => (c - 1 + images.length) % images.length)} className="absolute left-2 top-1/2 -translate-y-1/2 bg-background/60 rounded-full p-1">
            <ChevronLeft size={20} className="text-foreground" />
          </button>
          <button onClick={() => setCurrent((c) => (c + 1) % images.length)} className="absolute right-2 top-1/2 -translate-y-1/2 bg-background/60 rounded-full p-1">
            <ChevronRight size={20} className="text-foreground" />
          </button>
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5">
            {images.map((_, i) => (
              <div key={i} className={`w-2 h-2 rounded-full transition-colors ${i === current ? "bg-primary" : "bg-foreground/30"}`} />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default ImageSlider;
