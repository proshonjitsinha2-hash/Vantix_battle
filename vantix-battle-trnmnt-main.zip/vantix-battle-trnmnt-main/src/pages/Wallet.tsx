import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Wallet as WalletIcon, Upload, CheckCircle, XCircle, Loader2 } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import { toast } from "sonner";
import paymentQR from "@/assets/payment-qr.jpg";

type AddStep = "amount" | "qr" | "upload" | "verifying" | "result";

const Wallet = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const queryClient = useQueryClient();
  const balance = profile?.balance ?? 0;

  const [activeTab, setActiveTab] = useState<"add" | "withdraw" | "history">("add");
  const [addStep, setAddStep] = useState<AddStep>("amount");
  const [addMoneyAmount, setAddMoneyAmount] = useState("");
  const [withdrawEmail, setWithdrawEmail] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [screenshotFile, setScreenshotFile] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [verificationResult, setVerificationResult] = useState<{ status: string; message?: string; error?: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: transactions = [] } = useQuery({
    queryKey: ["transactions", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("transactions")
        .select("*")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const handleProceedToQR = () => {
    if (!addMoneyAmount || Number(addMoneyAmount) <= 0) {
      toast.error("Enter a valid amount");
      return;
    }
    setAddStep("qr");
  };

  const handleProceedToUpload = () => {
    setAddStep("upload");
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("File too large (max 5MB)");
      return;
    }
    setScreenshotFile(file);
    const reader = new FileReader();
    reader.onload = (ev) => setScreenshotPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleVerifyPayment = async () => {
    if (!screenshotFile || !user) return;
    setAddStep("verifying");
    setVerificationResult(null);

    try {
      // Upload screenshot
      const filePath = `${user.id}/${Date.now()}_${screenshotFile.name}`;
      const { error: uploadError } = await supabase.storage
        .from("payment-screenshots")
        .upload(filePath, screenshotFile);

      if (uploadError) {
        toast.error("Failed to upload screenshot");
        setAddStep("upload");
        return;
      }

      // Create verification record
      const { data: verification, error: insertError } = await supabase
        .from("payment_verifications")
        .insert({
          user_id: user.id,
          amount: Number(addMoneyAmount),
          screenshot_url: filePath,
          status: "pending",
        })
        .select("id")
        .single();

      if (insertError || !verification) {
        toast.error("Failed to create verification request");
        setAddStep("upload");
        return;
      }

      // Call edge function to verify
      const { data, error } = await supabase.functions.invoke("verify-payment", {
        body: { verification_id: verification.id },
      });

      if (error) {
        const errorMsg = data?.error || error.message || "Verification failed";
        setVerificationResult({ status: "rejected", error: errorMsg });
      } else {
        setVerificationResult({ status: data.status, message: data.message, error: data.error });
        if (data.status === "verified") {
          queryClient.invalidateQueries({ queryKey: ["profile"] });
          queryClient.invalidateQueries({ queryKey: ["transactions"] });
        }
      }
      setAddStep("result");
    } catch (err: any) {
      setVerificationResult({ status: "rejected", error: err.message || "Something went wrong" });
      setAddStep("result");
    }
  };

  const resetAddFlow = () => {
    setAddStep("amount");
    setAddMoneyAmount("");
    setScreenshotFile(null);
    setScreenshotPreview(null);
    setVerificationResult(null);
  };

  const handleWithdraw = async () => {
    if (!withdrawEmail || !withdrawAmount || Number(withdrawAmount) <= 0) return;
    if (Number(withdrawAmount) > balance) {
      toast.error("Insufficient balance");
      return;
    }
    const { error } = await supabase.from("withdrawal_requests").insert({
      user_id: user!.id,
      email: withdrawEmail,
      amount: Number(withdrawAmount),
    });
    if (error) {
      toast.error("Failed to submit request");
      return;
    }
    toast.success("Withdrawal request submitted!");
    setWithdrawEmail("");
    setWithdrawAmount("");
  };

  const inputClass = "w-full rounded-lg border border-border bg-background px-4 py-3 text-foreground font-body placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary";

  return (
    <div className="min-h-screen grid-bg pb-20">
      <header className="sticky top-0 z-40 flex items-center gap-3 px-4 py-3 bg-background/90 backdrop-blur-md border-b border-border">
        <button onClick={() => navigate("/home")} className="p-1">
          <ArrowLeft size={22} className="text-foreground" />
        </button>
        <h1 className="font-display font-bold text-lg text-gradient">WALLET</h1>
      </header>

      <div className="p-4 space-y-4">
        <div className="text-center py-4">
          <WalletIcon size={32} className="mx-auto text-primary mb-2" />
          <p className="text-3xl font-display font-bold text-primary">₹{balance}</p>
          <p className="text-sm text-muted-foreground font-body">Available Balance</p>
        </div>

        <div className="flex gap-2">
          {(["add", "withdraw", "history"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => { setActiveTab(tab); if (tab === "add") resetAddFlow(); }}
              className={`flex-1 py-2.5 rounded-lg font-display text-sm font-bold transition-colors ${activeTab === tab ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground border border-border"}`}
            >
              {tab === "add" ? "ADD" : tab === "withdraw" ? "WITHDRAW" : "HISTORY"}
            </button>
          ))}
        </div>

        {activeTab === "add" && (
          <div className="space-y-4">
            {addStep === "amount" && (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground font-body text-center">Enter the amount you want to add</p>
                <input
                  type="number"
                  placeholder="Enter amount (₹)"
                  value={addMoneyAmount}
                  onChange={(e) => setAddMoneyAmount(e.target.value)}
                  className={inputClass}
                />
                <button
                  onClick={handleProceedToQR}
                  className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground tracking-wider hover:opacity-90 transition-opacity"
                >
                  PROCEED
                </button>
              </div>
            )}

            {addStep === "qr" && (
              <div className="space-y-4 text-center">
                <p className="text-sm text-muted-foreground font-body">
                  Pay <span className="text-primary font-bold">₹{addMoneyAmount}</span> to the QR code below
                </p>
                <div className="bg-card rounded-xl p-4 border border-border inline-block mx-auto">
                  <img src={paymentQR} alt="Payment QR Code" className="w-56 h-56 mx-auto rounded-lg" />
                </div>
                <p className="text-xs text-muted-foreground font-body">UPI ID: 6900923598@ptaxis</p>
                <p className="text-xs text-destructive font-body font-bold">
                  Pay exactly ₹{addMoneyAmount} — amount mismatch will be rejected
                </p>
                <button
                  onClick={handleProceedToUpload}
                  className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground tracking-wider hover:opacity-90 transition-opacity"
                >
                  I'VE PAID — UPLOAD SCREENSHOT
                </button>
                <button
                  onClick={resetAddFlow}
                  className="w-full rounded-lg bg-card py-3 font-display font-bold text-muted-foreground border border-border"
                >
                  CANCEL
                </button>
              </div>
            )}

            {addStep === "upload" && (
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground font-body text-center">
                  Upload your payment screenshot for ₹{addMoneyAmount}
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                {screenshotPreview ? (
                  <div className="space-y-3">
                    <img src={screenshotPreview} alt="Screenshot preview" className="w-full max-h-80 object-contain rounded-lg border border-border" />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full rounded-lg bg-card py-2.5 font-display text-sm font-bold text-muted-foreground border border-border"
                    >
                      CHANGE SCREENSHOT
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full rounded-xl border-2 border-dashed border-border bg-card py-10 flex flex-col items-center gap-2"
                  >
                    <Upload size={32} className="text-muted-foreground" />
                    <span className="text-sm text-muted-foreground font-body">Tap to select screenshot</span>
                  </button>
                )}
                <button
                  onClick={handleVerifyPayment}
                  disabled={!screenshotFile}
                  className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground tracking-wider hover:opacity-90 transition-opacity disabled:opacity-50"
                >
                  VERIFY PAYMENT
                </button>
                <button
                  onClick={resetAddFlow}
                  className="w-full rounded-lg bg-card py-3 font-display font-bold text-muted-foreground border border-border"
                >
                  CANCEL
                </button>
              </div>
            )}

            {addStep === "verifying" && (
              <div className="flex flex-col items-center gap-4 py-10">
                <Loader2 size={40} className="text-primary animate-spin" />
                <p className="text-sm text-muted-foreground font-body">Verifying your payment...</p>
                <p className="text-xs text-muted-foreground font-body">This may take a few seconds</p>
              </div>
            )}

            {addStep === "result" && verificationResult && (
              <div className="flex flex-col items-center gap-4 py-6">
                {verificationResult.status === "verified" ? (
                  <>
                    <CheckCircle size={48} className="text-success" />
                    <p className="text-lg font-display font-bold text-success">Payment Verified!</p>
                    <p className="text-sm text-muted-foreground font-body text-center">{verificationResult.message}</p>
                  </>
                ) : (
                  <>
                    <XCircle size={48} className="text-destructive" />
                    <p className="text-lg font-display font-bold text-destructive">Payment Rejected</p>
                    <p className="text-sm text-muted-foreground font-body text-center">{verificationResult.error}</p>
                  </>
                )}
                <button
                  onClick={resetAddFlow}
                  className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground tracking-wider hover:opacity-90 transition-opacity mt-2"
                >
                  {verificationResult.status === "verified" ? "DONE" : "TRY AGAIN"}
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === "withdraw" && (
          <div className="space-y-3">
            <input type="email" placeholder="Your email" value={withdrawEmail} onChange={(e) => setWithdrawEmail(e.target.value)} className={inputClass} />
            <input type="number" placeholder="Amount" value={withdrawAmount} onChange={(e) => setWithdrawAmount(e.target.value)} className={inputClass} />
            <button onClick={handleWithdraw} className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground tracking-wider hover:opacity-90 transition-opacity">
              REQUEST WITHDRAWAL
            </button>
          </div>
        )}

        {activeTab === "history" && (
          <div className="space-y-2">
            {transactions.length === 0 ? (
              <p className="text-center py-8 text-muted-foreground font-body">No transactions yet</p>
            ) : (
              transactions.map((t: any) => (
                <div key={t.id} className="flex items-center justify-between p-3 rounded-lg bg-card border border-border">
                  <div>
                    <p className="text-sm font-body text-foreground capitalize">{t.type.replace("_", " ")}</p>
                    <p className="text-xs text-muted-foreground font-body">{new Date(t.created_at).toLocaleDateString()}</p>
                  </div>
                  <span className={`font-display font-bold text-sm ${t.amount > 0 ? "text-success" : "text-destructive"}`}>
                    {t.amount > 0 ? "+" : ""}₹{t.amount}
                  </span>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Wallet;
