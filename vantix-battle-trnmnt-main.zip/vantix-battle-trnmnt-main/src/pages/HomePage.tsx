import { useNavigate } from "react-router-dom";
import { Wallet, Mail, Crosshair, Megaphone } from "lucide-react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import logo from "@/assets/logo.jpg";
import ImageSlider from "@/components/ImageSlider";
import ReferEarnCard from "@/components/ReferEarnCard";

const HomePage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = useProfile();

  const balance = profile?.balance ?? 0;

  const { data: mails = [] } = useQuery({
    queryKey: ["mails", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("mails")
        .select("*")
        .eq("user_id", user!.id)
        .eq("claimed", false);
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const unclaimedCount = mails.length;

  const { data: notice } = useQuery({
    queryKey: ["active_notice"],
    queryFn: async () => {
      const { data } = await supabase
        .from("notices")
        .select("*")
        .eq("active", true)
        .order("updated_at", { ascending: false })
        .limit(1)
        .single();
      return data;
    },
  });

  return (
    <div className="min-h-screen grid-bg pb-20">
      <header className="sticky top-0 z-40 flex items-center justify-between px-4 py-3 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="flex items-center gap-2">
          <img src={logo} alt="Vantix" className="w-8 h-8 rounded-lg" />
          <span className="font-display font-bold text-lg text-gradient">VANTIX BATTLE</span>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/mailbox")} className="relative p-2 rounded-lg bg-card hover:bg-muted transition-colors">
            <Mail size={20} className="text-foreground" />
            {unclaimedCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-primary rounded-full text-[10px] font-bold flex items-center justify-center text-primary-foreground">
                {unclaimedCount}
              </span>
            )}
          </button>
          <button onClick={() => navigate("/wallet")} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-card hover:bg-muted transition-colors">
            <Wallet size={18} className="text-primary" />
            <span className="font-display font-bold text-sm text-foreground">₹{balance}</span>
          </button>
        </div>
      </header>

      <div className="p-4 space-y-4">
        {notice?.text && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex items-stretch rounded-xl overflow-hidden border border-border bg-card">
            <div className="flex items-center justify-center px-3 bg-primary/20">
              <Megaphone size={22} className="text-primary" />
            </div>
            <div className="flex-1 px-3 py-2.5 bg-foreground/5">
              <p className="text-sm font-body font-medium text-foreground">{notice.text}</p>
            </div>
          </motion.div>
        )}

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <ImageSlider />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <h2 className="font-display font-bold text-lg text-foreground mb-3">GAME MODES</h2>
          <button
            onClick={() => navigate("/freefire")}
            className="w-full rounded-xl bg-card p-4 flex items-center gap-4 hover:bg-muted transition-colors border border-border"
          >
            <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center">
              <Crosshair size={28} className="text-primary" />
            </div>
            <div className="text-left">
              <h3 className="font-display font-bold text-foreground">FREE FIRE</h3>
              <p className="text-sm text-muted-foreground font-body">Battle Royale & 1v1 Matches</p>
            </div>
          </button>
        </motion.div>

        {/* Refer & Earn - below Free Fire */}
        <ReferEarnCard />
      </div>
    </div>
  );
};

export default HomePage;
