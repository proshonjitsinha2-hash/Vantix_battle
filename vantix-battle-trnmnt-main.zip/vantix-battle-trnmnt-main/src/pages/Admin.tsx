import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Users, Gamepad2, Image, Mail, Gift, CreditCard, Plus, Trash2, Check, X, Upload, Search, Pencil, Megaphone } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useIsAdmin } from "@/hooks/useProfile";
import { toast } from "sonner";

type AdminTab = "users" | "matches" | "slider" | "mail" | "promo" | "withdrawals" | "notice";

const Admin = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: isAdmin, isLoading: adminLoading } = useIsAdmin();
  const queryClient = useQueryClient();

  const [tab, setTab] = useState<AdminTab>("matches");
  const [matchName, setMatchName] = useState("");
  const [matchType, setMatchType] = useState<"Bermuda" | "1v1">("Bermuda");
  const [matchDate, setMatchDate] = useState("");
  const [matchFee, setMatchFee] = useState("");
  const [matchPrize, setMatchPrize] = useState("");

  const [sliderLink, setSliderLink] = useState("");
  const [sliderUploading, setSliderUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [mailTo, setMailTo] = useState("");
  const [mailText, setMailText] = useState("");
  const [mailMoney, setMailMoney] = useState("");
  const [mailLink, setMailLink] = useState("");

  const [promoCodeInput, setPromoCodeInput] = useState("");
  const [promoReward, setPromoReward] = useState("");
  const [promoExpiry, setPromoExpiry] = useState("");

  // Edit match room - full screen overlay
  const [editMatchId, setEditMatchId] = useState<string | null>(null);
  const [editRoomId, setEditRoomId] = useState("");
  const [editRoomPass, setEditRoomPass] = useState("");
  // View participants - full screen overlay
  const [viewParticipantsMatchId, setViewParticipantsMatchId] = useState<string | null>(null);
  const [viewParticipantsMatchName, setViewParticipantsMatchName] = useState("");
  // User search & edit
  const [userSearch, setUserSearch] = useState("");
  const [editUserId, setEditUserId] = useState<string | null>(null);
  const [editUserName, setEditUserName] = useState("");
  const [editUserUid, setEditUserUid] = useState("");
  const [editUserBalance, setEditUserBalance] = useState("");
  const [editUserEarnings, setEditUserEarnings] = useState("");
  const [editUserMatches, setEditUserMatches] = useState("");
  const [noticeText, setNoticeText] = useState("");
  const [noticeLoaded, setNoticeLoaded] = useState(false);

  const tabs: { key: AdminTab; icon: typeof Users; label: string }[] = [
    { key: "users", icon: Users, label: "Users" },
    { key: "matches", icon: Gamepad2, label: "Matches" },
    { key: "slider", icon: Image, label: "Slider" },
    { key: "mail", icon: Mail, label: "Mail" },
    { key: "promo", icon: Gift, label: "Promo" },
    { key: "withdrawals", icon: CreditCard, label: "Withdraw" },
    { key: "notice", icon: Megaphone, label: "Notice" },
  ];

  const inputClass = "w-full rounded-lg border border-border bg-background px-4 py-2.5 text-foreground font-body placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-sm";

  // Data queries
  const { data: allProfiles = [] } = useQuery({
    queryKey: ["admin_profiles"],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("*").order("created_at", { ascending: false });
      return data || [];
    },
    enabled: !!isAdmin,
  });

  const { data: allMatches = [] } = useQuery({
    queryKey: ["admin_matches"],
    queryFn: async () => {
      const { data } = await supabase.from("matches").select("*, match_participants(count)").order("date_time", { ascending: false });
      return data || [];
    },
    enabled: !!isAdmin,
  });

  const { data: participants = [] } = useQuery({
    queryKey: ["admin_match_participants", viewParticipantsMatchId],
    queryFn: async () => {
      const { data: parts } = await supabase
        .from("match_participants")
        .select("*, profiles:user_id(in_game_name, uid)")
        .eq("match_id", viewParticipantsMatchId!);
      return parts || [];
    },
    enabled: !!viewParticipantsMatchId,
  });

  const { data: sliderImages = [] } = useQuery({
    queryKey: ["admin_slider"],
    queryFn: async () => {
      const { data } = await supabase.from("slider_images").select("*").order("sort_order");
      return data || [];
    },
    enabled: !!isAdmin,
  });

  const { data: promoCodes = [] } = useQuery({
    queryKey: ["admin_promos"],
    queryFn: async () => {
      const { data } = await supabase.from("promo_codes").select("*").order("created_at", { ascending: false });
      return data || [];
    },
    enabled: !!isAdmin,
  });

  const { data: withdrawals = [] } = useQuery({
    queryKey: ["admin_withdrawals"],
    queryFn: async () => {
      const { data } = await supabase.from("withdrawal_requests").select("*").order("created_at", { ascending: false });
      return data || [];
    },
    enabled: !!isAdmin,
  });




  const { data: currentNotice } = useQuery({
    queryKey: ["admin_notice"],
    queryFn: async () => {
      const { data } = await supabase
        .from("notices")
        .select("*")
        .eq("active", true)
        .order("updated_at", { ascending: false })
        .limit(1)
        .single();
      if (data && !noticeLoaded) {
        setNoticeText(data.text);
        setNoticeLoaded(true);
      }
      return data;
    },
    enabled: !!isAdmin,
  });

  // Mutations
  const createMatch = async () => {
    if (!matchName || !matchDate || !matchFee || !matchPrize) { toast.error("Fill all fields"); return; }
    const { error } = await supabase.from("matches").insert({
      name: matchName,
      type: matchType,
      date_time: new Date(matchDate).toISOString(),
      entry_fee: Number(matchFee),
      prize_pool: Number(matchPrize),
      max_players: matchType === "1v1" ? 2 : 32,
    });
    if (error) { toast.error(error.message); return; }
    toast.success("Match created!");
    setMatchName(""); setMatchDate(""); setMatchFee(""); setMatchPrize("");
    queryClient.invalidateQueries({ queryKey: ["admin_matches"] });
  };

  const updateMatchRoom = async (id: string) => {
    await supabase.from("matches").update({ match_id: editRoomId, password: editRoomPass }).eq("id", id);
    toast.success("Room details updated!");
    setEditMatchId(null); setEditRoomId(""); setEditRoomPass("");
    queryClient.invalidateQueries({ queryKey: ["admin_matches"] });
  };

  const deleteMatch = async (id: string) => {
    await supabase.from("matches").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["admin_matches"] });
    toast.success("Match deleted");
  };

  const handleSliderUpload = async (file: File) => {
    setSliderUploading(true);
    const fileExt = file.name.split(".").pop();
    const filePath = `${Date.now()}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from("slider-images")
      .upload(filePath, file);

    if (uploadError) {
      toast.error("Upload failed: " + uploadError.message);
      setSliderUploading(false);
      return;
    }

    const { data: urlData } = supabase.storage
      .from("slider-images")
      .getPublicUrl(filePath);

    await supabase.from("slider_images").insert({
      image_url: urlData.publicUrl,
      redirect_link: sliderLink,
      sort_order: sliderImages.length,
    });

    setSliderLink("");
    setSliderUploading(false);
    queryClient.invalidateQueries({ queryKey: ["admin_slider"] });
    toast.success("Slider image added!");
  };

  const deleteSlider = async (id: string) => {
    await supabase.from("slider_images").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["admin_slider"] });
  };

  const sendMail = async () => {
    if (!mailText) { toast.error("Message required"); return; }
    const targets = mailTo.toLowerCase() === "all"
      ? allProfiles.map((p) => p.id)
      : allProfiles.filter((p) => p.uid === mailTo).map((p) => p.id);
    if (targets.length === 0) { toast.error("No users found"); return; }
    const rows = targets.map((uid) => ({
      user_id: uid,
      message: mailText,
      money: mailMoney ? Number(mailMoney) : null,
      link: mailLink || null,
    }));
    await supabase.from("mails").insert(rows);
    toast.success(`Mail sent to ${targets.length} user(s)!`);
    setMailTo(""); setMailText(""); setMailMoney(""); setMailLink("");
  };

  const createPromo = async () => {
    if (!promoCodeInput || !promoReward || !promoExpiry) { toast.error("Fill all fields"); return; }
    const { error } = await supabase.from("promo_codes").insert({
      code: promoCodeInput.toUpperCase(),
      reward: Number(promoReward),
      expires_at: promoExpiry,
    });
    if (error) { toast.error(error.message); return; }
    toast.success("Promo code created!");
    setPromoCodeInput(""); setPromoReward(""); setPromoExpiry("");
    queryClient.invalidateQueries({ queryKey: ["admin_promos"] });
  };

  const deletePromo = async (id: string) => {
    await supabase.from("promo_codes").delete().eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["admin_promos"] });
  };

  const updateWithdrawal = async (id: string, status: string) => {
    await supabase.from("withdrawal_requests").update({ status }).eq("id", id);
    queryClient.invalidateQueries({ queryKey: ["admin_withdrawals"] });
    toast.success(`Withdrawal ${status}`);
  };




  if (adminLoading) {
    return <div className="min-h-screen grid-bg flex items-center justify-center"><div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" /></div>;
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen grid-bg flex items-center justify-center p-6">
        <div className="text-center w-full max-w-sm space-y-4">
          <h1 className="font-display font-bold text-2xl text-foreground mb-2">ACCESS DENIED</h1>
          <p className="text-muted-foreground font-body">You don't have admin access.</p>
          <button onClick={() => navigate("/home")} className="text-sm text-muted-foreground hover:text-foreground font-body">
            Go back
          </button>
        </div>
      </div>
    );
  }

  // Get current editing match for full-screen overlay
  const editingMatch = editMatchId ? allMatches.find((m: any) => m.id === editMatchId) : null;

  return (
    <div className="min-h-screen grid-bg">
      <header className="sticky top-0 z-40 flex items-center gap-3 px-4 py-3 bg-background/90 backdrop-blur-md border-b border-border">
        <button onClick={() => navigate("/home")} className="p-1">
          <ArrowLeft size={22} className="text-foreground" />
        </button>
        <h1 className="font-display font-bold text-lg text-gradient">ADMIN PANEL</h1>
      </header>

      <div className="flex overflow-x-auto gap-1 p-3 border-b border-border no-scrollbar">
        {tabs.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)} className={`flex items-center gap-1.5 px-3 py-2 rounded-lg font-display text-xs font-bold whitespace-nowrap transition-colors ${tab === t.key ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground"}`}>
            <t.icon size={14} />
            {t.label}
          </button>
        ))}
      </div>

      <div className="p-4">
        {/* Users */}
        {tab === "users" && (
          <div className="space-y-3">
            <h3 className="font-display font-bold text-foreground">ALL USERS ({allProfiles.length})</h3>
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder="Search by UID..."
                className={inputClass + " pl-9"}
              />
            </div>
            {allProfiles
              .filter((p) => !userSearch || p.uid.toLowerCase().includes(userSearch.toLowerCase()))
              .map((p) => (
              <div key={p.id} className="p-3 rounded-lg bg-card border border-border flex items-center justify-between">
                <div>
                  <p className="font-display font-bold text-foreground text-sm">{p.in_game_name}</p>
                  <p className="text-xs text-muted-foreground font-body">UID: {p.uid} | Balance: ₹{p.balance}</p>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      setEditUserId(p.id);
                      setEditUserName(p.in_game_name);
                      setEditUserUid(p.uid);
                      setEditUserBalance(String(p.balance));
                      setEditUserEarnings(String(p.total_earnings));
                      setEditUserMatches(String(p.matches_played));
                    }}
                    className="text-primary hover:bg-primary/10 p-2 rounded-lg transition-colors"
                  >
                    <Pencil size={16} />
                  </button>
                  <button
                    onClick={async () => {
                      if (!confirm(`Delete user ${p.in_game_name}?`)) return;
                      const { data: session } = await supabase.auth.getSession();
                      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/delete-user`, {
                        method: "POST",
                        headers: {
                          "Content-Type": "application/json",
                          Authorization: `Bearer ${session.session?.access_token}`,
                        },
                        body: JSON.stringify({ user_id: p.id }),
                      });
                      const result = await res.json();
                      if (result.error) { toast.error(result.error); return; }
                      toast.success("User deleted");
                      queryClient.invalidateQueries({ queryKey: ["admin_profiles"] });
                    }}
                    className="text-destructive hover:bg-destructive/10 p-2 rounded-lg transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Matches */}
        {tab === "matches" && (
          <div className="space-y-4">
            <h3 className="font-display font-bold text-foreground">CREATE MATCH</h3>
            <input value={matchName} onChange={(e) => setMatchName(e.target.value)} placeholder="Match name" className={inputClass} />
            <select value={matchType} onChange={(e) => setMatchType(e.target.value as any)} className={inputClass}>
              <option value="Bermuda">Bermuda (32 players)</option>
              <option value="1v1">1v1 (2 players)</option>
            </select>
            <input type="datetime-local" value={matchDate} onChange={(e) => setMatchDate(e.target.value)} className={inputClass} />
            <div className="grid grid-cols-2 gap-3">
              <input type="number" value={matchFee} onChange={(e) => setMatchFee(e.target.value)} placeholder="Entry Fee (₹)" className={inputClass} />
              <input type="number" value={matchPrize} onChange={(e) => setMatchPrize(e.target.value)} placeholder="Prize Pool (₹)" className={inputClass} />
            </div>
            <button onClick={createMatch} className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground tracking-wider hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
              <Plus size={18} /> CREATE MATCH
            </button>

            <h3 className="font-display font-bold text-foreground mt-6">PUBLISHED MATCHES</h3>
            {allMatches.map((m: any) => (
              <div key={m.id} className="p-3 rounded-lg bg-card border border-border space-y-2">
                <div className="flex items-center justify-between">
                  <p className="font-display font-bold text-foreground text-sm">{m.name}</p>
                  <button onClick={() => deleteMatch(m.id)} className="text-destructive"><Trash2 size={16} /></button>
                </div>
                <p className="text-xs text-muted-foreground font-body">{m.type} | ₹{m.entry_fee} | Prize: ₹{m.prize_pool} | Players: {m.match_participants?.[0]?.count ?? 0}/{m.max_players}</p>
                {m.match_id && <p className="text-xs text-primary font-body">Room: {m.match_id} | Pass: {m.password}</p>}
                <div className="flex gap-2">
                  <button
                    onClick={() => { setEditMatchId(m.id); setEditRoomId(m.match_id || ""); setEditRoomPass(m.password || ""); }}
                    className="text-xs text-primary font-body underline"
                  >
                    {m.match_id ? "Edit Room" : "Add Room ID & Password"}
                  </button>
                  <button
                    onClick={() => { setViewParticipantsMatchId(m.id); setViewParticipantsMatchName(m.name); }}
                    className="text-xs text-primary font-body underline"
                  >
                    View Players
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Slider */}
        {tab === "slider" && (
          <div className="space-y-4">
            <h3 className="font-display font-bold text-foreground">IMAGE SLIDER</h3>
            <input value={sliderLink} onChange={(e) => setSliderLink(e.target.value)} placeholder="Redirect Link (optional)" className={inputClass} />
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleSliderUpload(file);
                e.target.value = "";
              }}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={sliderUploading}
              className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground tracking-wider hover:opacity-90 transition-opacity flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {sliderUploading ? (
                <div className="w-5 h-5 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Upload size={18} /> UPLOAD IMAGE
                </>
              )}
            </button>
            {sliderImages.map((img) => (
              <div key={img.id} className="flex items-center gap-3 p-2 rounded-lg bg-card border border-border">
                <img src={img.image_url} alt="" className="w-16 h-10 object-cover rounded" />
                <p className="flex-1 text-xs text-muted-foreground font-body truncate">{img.redirect_link}</p>
                <button onClick={() => deleteSlider(img.id)} className="text-destructive"><Trash2 size={16} /></button>
              </div>
            ))}
          </div>
        )}

        {/* Mail */}
        {tab === "mail" && (
          <div className="space-y-4">
            <h3 className="font-display font-bold text-foreground">SEND MAIL</h3>
            <input value={mailTo} onChange={(e) => setMailTo(e.target.value)} placeholder="Send to (UID or 'all')" className={inputClass} />
            <textarea value={mailText} onChange={(e) => setMailText(e.target.value)} placeholder="Message text" rows={3} className={inputClass + " resize-none"} />
            <input type="number" value={mailMoney} onChange={(e) => setMailMoney(e.target.value)} placeholder="Attach money (₹) - optional" className={inputClass} />
            <input value={mailLink} onChange={(e) => setMailLink(e.target.value)} placeholder="Attach link - optional" className={inputClass} />
            <button onClick={sendMail} className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground tracking-wider hover:opacity-90 transition-opacity">
              SEND MAIL
            </button>
          </div>
        )}

        {/* Promo */}
        {tab === "promo" && (
          <div className="space-y-4">
            <h3 className="font-display font-bold text-foreground">CREATE PROMO CODE</h3>
            <input value={promoCodeInput} onChange={(e) => setPromoCodeInput(e.target.value)} placeholder="Promo code" className={inputClass} />
            <input type="number" value={promoReward} onChange={(e) => setPromoReward(e.target.value)} placeholder="Reward amount (₹)" className={inputClass} />
            <input type="date" value={promoExpiry} onChange={(e) => setPromoExpiry(e.target.value)} className={inputClass} />
            <button onClick={createPromo} className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground tracking-wider hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
              <Plus size={18} /> CREATE CODE
            </button>
            {promoCodes.map((p) => (
              <div key={p.id} className="flex items-center justify-between p-3 rounded-lg bg-card border border-border">
                <div>
                  <p className="font-display font-bold text-foreground text-sm">{p.code}</p>
                  <p className="text-xs text-muted-foreground font-body">₹{p.reward} | Expires: {p.expires_at}</p>
                </div>
                <button onClick={() => deletePromo(p.id)} className="text-destructive"><Trash2 size={16} /></button>
              </div>
            ))}
          </div>
        )}

        {/* Withdrawals */}
        {tab === "withdrawals" && (
          <div className="space-y-3">
            <h3 className="font-display font-bold text-foreground">WITHDRAWAL REQUESTS</h3>
            {withdrawals.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground font-body">
                <CreditCard size={40} className="mx-auto mb-2 opacity-50" />
                <p>No withdrawal requests</p>
              </div>
            ) : (
              withdrawals.map((w) => (
                <div key={w.id} className="p-3 rounded-lg bg-card border border-border">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-body text-sm text-foreground">{w.email}</p>
                      <p className="text-xs text-muted-foreground font-body">₹{w.amount} | {new Date(w.created_at).toLocaleDateString()}</p>
                    </div>
                    <span className={`text-xs font-display font-bold px-2 py-1 rounded-full ${w.status === "pending" ? "bg-warning/20 text-warning" : w.status === "approved" ? "bg-success/20 text-success" : "bg-destructive/20 text-destructive"}`}>
                      {w.status.toUpperCase()}
                    </span>
                  </div>
                  {w.status === "pending" && (
                    <div className="flex gap-2 mt-2">
                      <button onClick={() => updateWithdrawal(w.id, "approved")} className="flex-1 py-1.5 rounded-lg bg-success/20 text-success font-display font-bold text-xs flex items-center justify-center gap-1">
                        <Check size={14} /> APPROVE
                      </button>
                      <button onClick={() => updateWithdrawal(w.id, "rejected")} className="flex-1 py-1.5 rounded-lg bg-destructive/20 text-destructive font-display font-bold text-xs flex items-center justify-center gap-1">
                        <X size={14} /> REJECT
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}




        {/* Notice */}
        {tab === "notice" && (
          <div className="space-y-4">
            <h3 className="font-display font-bold text-foreground">HOME NOTICE BANNER</h3>
            <p className="text-sm text-muted-foreground font-body">Yeh text home page ke image slider ke upar dikhega.</p>
            <textarea
              value={noticeText}
              onChange={(e) => setNoticeText(e.target.value)}
              placeholder="Notice text likhein..."
              rows={3}
              className={inputClass}
            />
            <button
              onClick={async () => {
                if (currentNotice?.id) {
                  const { error } = await supabase.from("notices").update({ text: noticeText, updated_at: new Date().toISOString() }).eq("id", currentNotice.id);
                  if (error) { toast.error(error.message); return; }
                } else {
                  const { error } = await supabase.from("notices").insert({ text: noticeText, active: true });
                  if (error) { toast.error(error.message); return; }
                }
                toast.success("Notice updated!");
                queryClient.invalidateQueries({ queryKey: ["admin_notice"] });
                queryClient.invalidateQueries({ queryKey: ["active_notice"] });
              }}
              className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground tracking-wider hover:opacity-90 transition-opacity"
            >
              SAVE NOTICE
            </button>
          </div>
        )}
      </div>

      {/* Full-screen Room ID/Password overlay */}
      {editMatchId && (
        <div className="fixed inset-0 z-50 bg-background flex flex-col">
          <header className="flex items-center gap-3 px-4 py-3 border-b border-border">
            <button onClick={() => { setEditMatchId(null); setEditRoomId(""); setEditRoomPass(""); }} className="p-1">
              <ArrowLeft size={22} className="text-foreground" />
            </button>
            <h1 className="font-display font-bold text-lg text-gradient">ROOM DETAILS</h1>
          </header>
          <div className="flex-1 p-4 space-y-4">
            {editingMatch && (
              <div className="p-3 rounded-lg bg-card border border-border">
                <p className="font-display font-bold text-foreground">{(editingMatch as any).name}</p>
                <p className="text-xs text-muted-foreground font-body mt-1">{(editingMatch as any).type} | ₹{(editingMatch as any).entry_fee} entry</p>
              </div>
            )}
            <div className="space-y-3">
              <label className="text-sm font-display font-bold text-foreground">Room ID</label>
              <input value={editRoomId} onChange={(e) => setEditRoomId(e.target.value)} placeholder="Enter Room ID" className={inputClass} />
            </div>
            <div className="space-y-3">
              <label className="text-sm font-display font-bold text-foreground">Password</label>
              <input value={editRoomPass} onChange={(e) => setEditRoomPass(e.target.value)} placeholder="Enter Password" className={inputClass} />
            </div>
            <button
              onClick={() => updateMatchRoom(editMatchId)}
              className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground tracking-wider hover:opacity-90 transition-opacity"
            >
              SAVE ROOM DETAILS
            </button>
          </div>
        </div>
      )}

      {/* Full-screen Players overlay */}
      {viewParticipantsMatchId && (
        <div className="fixed inset-0 z-50 bg-background flex flex-col">
          <header className="flex items-center gap-3 px-4 py-3 border-b border-border">
            <button onClick={() => { setViewParticipantsMatchId(null); setViewParticipantsMatchName(""); }} className="p-1">
              <ArrowLeft size={22} className="text-foreground" />
            </button>
            <div>
              <h1 className="font-display font-bold text-lg text-gradient">JOINED PLAYERS</h1>
              <p className="text-xs text-muted-foreground font-body">{viewParticipantsMatchName}</p>
            </div>
          </header>
          <div className="flex-1 p-4 overflow-y-auto">
            <p className="text-sm font-display font-bold text-foreground mb-3">TOTAL: {participants.length}</p>
            {participants.length === 0 ? (
              <div className="text-center py-16 text-muted-foreground font-body">
                <Users size={40} className="mx-auto mb-2 opacity-50" />
                <p>No players joined yet</p>
              </div>
            ) : (
              <div className="space-y-2">
                {participants.map((p: any, idx: number) => (
                  <div key={p.id} className="flex items-center justify-between p-3 rounded-lg bg-card border border-border">
                    <div className="flex items-center gap-3">
                      <span className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center text-xs font-display font-bold text-primary">{idx + 1}</span>
                      <div>
                        <p className="text-sm font-display font-bold text-foreground">{p.profiles?.in_game_name || "Unknown"}</p>
                        <p className="text-[10px] text-muted-foreground font-body">UID: {p.profiles?.uid || "N/A"}</p>
                      </div>
                    </div>
                    <p className="text-[10px] text-muted-foreground font-body">{new Date(p.joined_at).toLocaleDateString()}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Full-screen Edit User overlay */}
      {editUserId && (
        <div className="fixed inset-0 z-50 bg-background flex flex-col">
          <header className="flex items-center gap-3 px-4 py-3 border-b border-border">
            <button onClick={() => setEditUserId(null)} className="p-1">
              <ArrowLeft size={22} className="text-foreground" />
            </button>
            <h1 className="font-display font-bold text-lg text-gradient">EDIT USER</h1>
          </header>
          <div className="flex-1 p-4 space-y-4 overflow-y-auto">
            <div className="space-y-2">
              <label className="text-sm font-display font-bold text-foreground">In-Game Name</label>
              <input value={editUserName} onChange={(e) => setEditUserName(e.target.value)} className={inputClass} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-display font-bold text-foreground">UID</label>
              <input value={editUserUid} onChange={(e) => setEditUserUid(e.target.value)} className={inputClass} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-display font-bold text-foreground">Balance (₹)</label>
              <input type="number" value={editUserBalance} onChange={(e) => setEditUserBalance(e.target.value)} className={inputClass} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-display font-bold text-foreground">Total Earnings (₹)</label>
              <input type="number" value={editUserEarnings} onChange={(e) => setEditUserEarnings(e.target.value)} className={inputClass} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-display font-bold text-foreground">Matches Played</label>
              <input type="number" value={editUserMatches} onChange={(e) => setEditUserMatches(e.target.value)} className={inputClass} />
            </div>
            <button
              onClick={async () => {
                const { error } = await supabase.from("profiles").update({
                  in_game_name: editUserName,
                  uid: editUserUid,
                  balance: Number(editUserBalance),
                  total_earnings: Number(editUserEarnings),
                  matches_played: Number(editUserMatches),
                }).eq("id", editUserId);
                if (error) { toast.error(error.message); return; }
                toast.success("Profile updated!");
                setEditUserId(null);
                queryClient.invalidateQueries({ queryKey: ["admin_profiles"] });
              }}
              className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground tracking-wider hover:opacity-90 transition-opacity"
            >
              SAVE CHANGES
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Admin;
