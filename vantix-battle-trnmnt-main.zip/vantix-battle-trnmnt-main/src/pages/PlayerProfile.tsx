import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { ArrowLeft, User, UserPlus, UserCheck, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { LevelProgressCard } from "@/components/profile/LevelProgressCard";
import { getLevelColor, getLevelEmoji } from "@/utils/levelSystem";
import {
  useFollowCounts,
  useFollowStatus,
  useSendFollowRequest,
  useCancelFollowRequest,
  useUnfollow,
} from "@/hooks/useFollow";

interface PublicProfile {
  id: string;
  in_game_name: string;
  uid: string;
  avatar_url: string | null;
  bio: string | null;
  level: number;
  level_name: string;
  experience_points: number;
}

const PlayerProfile = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [profile, setProfile] = useState<PublicProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  const uid = searchParams.get("uid");

  useEffect(() => {
    const fetchProfile = async () => {
      if (!uid) {
        setNotFound(true);
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("uid", uid)
        .single();

      if (error || !data) {
        setNotFound(true);
      } else {
        setProfile(data);
      }
      setLoading(false);
    };

    fetchProfile();
  }, [uid]);

  const { data: counts } = useFollowCounts(profile?.id);
  const { data: status } = useFollowStatus(profile?.id);
  const sendReq = useSendFollowRequest();
  const cancelReq = useCancelFollowRequest();
  const unfollow = useUnfollow();

  if (loading) {
    return (
      <div className="min-h-screen grid-bg flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (notFound || !profile) {
    return (
      <div className="min-h-screen grid-bg pb-20">
        <header className="sticky top-0 z-40 flex items-center gap-3 px-4 py-3 bg-background/90 backdrop-blur-md border-b border-border">
          <button onClick={() => navigate(-1)} className="p-1">
            <ArrowLeft size={22} className="text-foreground" />
          </button>
          <h1 className="font-display font-bold text-lg text-foreground">PLAYER PROFILE</h1>
        </header>
        <div className="text-center py-20 text-muted-foreground font-body">
          <User size={48} className="mx-auto mb-4 opacity-40" />
          <p>Player not found</p>
        </div>
      </div>
    );
  }

  const isOwnProfile = user?.id === profile.id;

  return (
    <div className="min-h-screen grid-bg pb-20">
      <header className="sticky top-0 z-40 flex items-center gap-3 px-4 py-3 bg-background/90 backdrop-blur-md border-b border-border">
        <button onClick={() => navigate(-1)} className="p-1">
          <ArrowLeft size={22} className="text-foreground" />
        </button>
        <h1 className="font-display font-bold text-lg text-foreground">PLAYER PROFILE</h1>
      </header>

      <div className="px-4 pt-8 pb-6 text-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="relative inline-block"
        >
          <div className="w-24 h-24 rounded-full bg-card border-2 border-primary flex items-center justify-center glow-orange overflow-hidden">
            {profile.avatar_url ? (
              <img src={profile.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="font-display font-bold text-3xl text-primary">
                {profile.in_game_name[0]}
              </span>
            )}
          </div>
        </motion.div>
        <h1 className="font-display font-bold text-xl text-foreground mt-3">
          {profile.in_game_name}
        </h1>
        <p className="text-sm text-muted-foreground font-body">UID: {profile.uid}</p>
        <div className={`inline-flex items-center gap-1.5 mt-2 font-display font-bold text-sm ${getLevelColor(profile.level_name || "Bronze")}`}>
          <span>{getLevelEmoji(profile.level_name || "Bronze")}</span>
          <span>{profile.level_name || "Bronze"}</span>
        </div>

        {/* Follower / Following counts */}
        <div className="mt-4 flex items-center justify-center gap-6">
          <div className="text-center">
            <p className="font-display font-bold text-lg text-foreground">{counts?.followers ?? 0}</p>
            <p className="text-xs text-muted-foreground font-body">Followers</p>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="text-center">
            <p className="font-display font-bold text-lg text-foreground">{counts?.following ?? 0}</p>
            <p className="text-xs text-muted-foreground font-body">Following</p>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-4">
        <LevelProgressCard
          xp={profile.experience_points || 0}
          level={profile.level || 1}
          levelName={profile.level_name || "Bronze"}
        />

        <div className="rounded-xl bg-card p-4 border border-border">
          <h3 className="font-display font-bold text-foreground mb-2">BIO</h3>
          <p className="text-sm text-muted-foreground font-body">
            {profile.bio || "No bio yet..."}
          </p>
        </div>

        {isOwnProfile && (
          <button
            onClick={() => navigate("/profile")}
            className="w-full py-3 rounded-xl bg-primary font-display font-bold text-primary-foreground hover:opacity-90 transition-opacity"
          >
            EDIT PROFILE
          </button>
        )}

        {!isOwnProfile && user && (
          <>
            {status?.isFollowing ? (
              <button
                onClick={() => unfollow.mutate(profile.id)}
                disabled={unfollow.isPending}
                className="w-full py-3 rounded-xl bg-card border border-border font-display font-bold text-foreground hover:bg-muted transition-colors flex items-center justify-center gap-2"
              >
                <UserCheck size={18} className="text-primary" />
                FOLLOWING
              </button>
            ) : status?.hasPending ? (
              <button
                onClick={() => cancelReq.mutate(profile.id)}
                disabled={cancelReq.isPending}
                className="w-full py-3 rounded-xl bg-card border border-border font-display font-bold text-muted-foreground hover:bg-muted transition-colors flex items-center justify-center gap-2"
              >
                <Clock size={18} />
                REQUEST PENDING
              </button>
            ) : (
              <button
                onClick={() => sendReq.mutate(profile.id)}
                disabled={sendReq.isPending}
                className="w-full py-3 rounded-xl bg-primary font-display font-bold text-primary-foreground hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
              >
                <UserPlus size={18} />
                FOLLOW
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default PlayerProfile;
