import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { motion } from "framer-motion";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import { toast } from "sonner";
import MatchCard, { Match } from "@/components/MatchCard";

const FreeFire = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<"upcoming" | "ongoing">("upcoming");

  const { data: matchesRaw = [] } = useQuery({
    queryKey: ["matches"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("matches")
        .select("*, match_participants(count)")
        .order("date_time", { ascending: true });
      if (error) throw error;
      return data;
    },
  });

  const now = new Date();
  const matches: Match[] = matchesRaw.map((m: any) => {
    const joinedPlayers = m.match_participants?.[0]?.count ?? 0;
    const isOngoing = new Date(m.date_time) <= now;
    return {
      id: m.id,
      name: m.name,
      type: m.type as "Bermuda" | "1v1",
      dateTime: m.date_time,
      entryFee: m.entry_fee,
      prizePool: m.prize_pool,
      matchId: m.match_id ?? undefined,
      password: m.password ?? undefined,
      maxPlayers: m.max_players,
      joinedPlayers,
      status: isOngoing ? "ongoing" : "upcoming",
    };
  });

  const filtered = matches.filter((m) => m.status === tab);

  const handleJoin = async (matchId: string) => {
    const match = matches.find((m) => m.id === matchId);
    if (!match || !user || !profile) return;

    if (profile.balance < match.entryFee) {
      toast.error("Insufficient balance! Add money to your wallet.");
      return;
    }

    // Insert participant
    const { error: joinError } = await supabase.from("match_participants").insert({
      match_id: matchId,
      user_id: user.id,
    });
    if (joinError) {
      if (joinError.code === "23505") toast.error("You already joined this match!");
      else toast.error("Failed to join match");
      return;
    }

    // Deduct balance
    await supabase.from("profiles").update({ balance: profile.balance - match.entryFee }).eq("id", user.id);
    await supabase.from("transactions").insert({
      user_id: user.id,
      type: "match_fee",
      amount: -match.entryFee,
      description: `Joined: ${match.name}`,
    });

    queryClient.invalidateQueries({ queryKey: ["matches"] });
    queryClient.invalidateQueries({ queryKey: ["profile"] });
    queryClient.invalidateQueries({ queryKey: ["transactions"] });
    toast.success(`Joined ${match.name}!`);
  };

  return (
    <div className="min-h-screen grid-bg pb-20">
      <header className="sticky top-0 z-40 flex items-center gap-3 px-4 py-3 bg-background/90 backdrop-blur-md border-b border-border">
        <button onClick={() => navigate("/home")} className="p-1">
          <ArrowLeft size={22} className="text-foreground" />
        </button>
        <h1 className="font-display font-bold text-lg text-foreground">FREE FIRE</h1>
      </header>

      <div className="flex gap-2 p-4">
        {(["upcoming", "ongoing"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 py-2.5 rounded-lg font-display text-sm font-bold transition-colors ${
              tab === t
                ? t === "upcoming"
                  ? "bg-success/20 text-success border border-success"
                  : "bg-destructive/20 text-destructive border border-destructive"
                : "bg-muted text-muted-foreground"
            }`}
          >
            {t.toUpperCase()}
          </button>
        ))}
      </div>

      <div className="px-4 space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground font-body">
            <p>No {tab} matches</p>
          </div>
        ) : (
          filtered.map((match, i) => (
            <motion.div key={match.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
              <MatchCard match={match} onJoin={handleJoin} />
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};

export default FreeFire;
