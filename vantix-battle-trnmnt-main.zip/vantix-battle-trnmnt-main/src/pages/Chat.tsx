import { useState, useEffect, useRef } from "react";
import { Search, Send, Settings, ShieldBan, Trash2, ArrowLeft, User, Lock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface ChatUser {
  id: string;
  uid: string;
  in_game_name: string;
}

const Chat = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [selectedUser, setSelectedUser] = useState<ChatUser | null>(null);
  const [message, setMessage] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch blocked users
  const { data: blockedIds = [] } = useQuery({
    queryKey: ["chat_blocks", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("chat_blocks")
        .select("blocked_id")
        .eq("blocker_id", user!.id);
      return (data || []).map((b: any) => b.blocked_id);
    },
    enabled: !!user,
  });

  // Fetch users who blocked me
  const { data: blockedByIds = [] } = useQuery({
    queryKey: ["chat_blocked_by", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("chat_blocks")
        .select("blocker_id")
        .eq("blocked_id", user!.id);
      return (data || []).map((b: any) => b.blocker_id);
    },
    enabled: !!user,
  });

  // People I follow
  const { data: followingIds = [] } = useQuery({
    queryKey: ["chat_following_ids", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("follows").select("following_id").eq("follower_id", user!.id);
      return (data || []).map((f: any) => f.following_id);
    },
    enabled: !!user,
  });

  // People who follow me
  const { data: followerIds = [] } = useQuery({
    queryKey: ["chat_follower_ids", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("follows").select("follower_id").eq("following_id", user!.id);
      return (data || []).map((f: any) => f.follower_id);
    },
    enabled: !!user,
  });

  const friendIds = followingIds.filter((id) => followerIds.includes(id));

  const { data: profiles = [] } = useQuery({
    queryKey: ["profiles"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("id, uid, in_game_name");
      if (error) throw error;
      return data.filter((p) => p.id !== user?.id) as ChatUser[];
    },
    enabled: !!user,
  });

  const filtered = profiles.filter(
    (u) =>
      !blockedIds.includes(u.id) &&
      !blockedByIds.includes(u.id) &&
      (u.in_game_name.toLowerCase().includes(search.toLowerCase()) || u.uid.includes(search))
  );
  const friendsFiltered = filtered.filter((u) => friendIds.includes(u.id));

  const { data: messages = [] } = useQuery({
    queryKey: ["chat_messages", selectedUser?.id],
    queryFn: async () => {
      if (!selectedUser || !user) return [];
      const { data, error } = await supabase
        .from("chat_messages")
        .select("*")
        .or(
          `and(sender_id.eq.${user.id},receiver_id.eq.${selectedUser.id}),and(sender_id.eq.${selectedUser.id},receiver_id.eq.${user.id})`
        )
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data;
    },
    enabled: !!selectedUser && !!user,
    refetchInterval: 3000,
  });

  useEffect(() => {
    if (!selectedUser || !user) return;
    const channel = supabase
      .channel(`chat-${selectedUser.id}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_messages" }, (payload) => {
        const msg = payload.new as any;
        if (
          (msg.sender_id === user.id && msg.receiver_id === selectedUser.id) ||
          (msg.sender_id === selectedUser.id && msg.receiver_id === user.id)
        ) {
          queryClient.invalidateQueries({ queryKey: ["chat_messages", selectedUser.id] });
        }
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [selectedUser, user, queryClient]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async () => {
    if (!message.trim() || !selectedUser || !user) return;
    const { error } = await supabase.from("chat_messages").insert({
      sender_id: user.id,
      receiver_id: selectedUser.id,
      message: message.trim(),
    });
    if (!error) {
      setMessage("");
      queryClient.invalidateQueries({ queryKey: ["chat_messages", selectedUser.id] });
    }
  };

  const blockUser = async () => {
    if (!selectedUser || !user) return;
    const { error } = await supabase.from("chat_blocks").insert({
      blocker_id: user.id,
      blocked_id: selectedUser.id,
    });
    if (error) { toast.error("Block failed"); return; }
    toast.success(`${selectedUser.in_game_name} blocked`);
    setShowSettings(false);
    setSelectedUser(null);
    queryClient.invalidateQueries({ queryKey: ["chat_blocks"] });
  };

  const deleteChat = async () => {
    if (!selectedUser || !user) return;
    // Delete messages sent by current user to this user
    await supabase
      .from("chat_messages")
      .delete()
      .eq("sender_id", user.id)
      .eq("receiver_id", selectedUser.id);
    // Delete messages received from this user  
    await supabase
      .from("chat_messages")
      .delete()
      .eq("sender_id", selectedUser.id)
      .eq("receiver_id", user.id);
    toast.success("Chat deleted");
    setShowSettings(false);
    setSelectedUser(null);
    queryClient.invalidateQueries({ queryKey: ["chat_messages"] });
  };

  if (selectedUser) {
    const isBlocked = blockedIds.includes(selectedUser.id);
    const isFriend = friendIds.includes(selectedUser.id);

    return (
      <div className="min-h-screen grid-bg pb-20 flex flex-col">
        <header className="sticky top-0 z-40 flex items-center justify-between px-4 py-3 bg-background/90 backdrop-blur-md border-b border-border">
          <div className="flex items-center gap-3">
            <button onClick={() => setSelectedUser(null)} className="text-foreground">
              <ArrowLeft size={22} />
            </button>
            <div>
              <h2 className="font-display font-bold text-foreground">{selectedUser.in_game_name}</h2>
              <p className="text-xs text-muted-foreground font-body">UID: {selectedUser.uid}</p>
            </div>
          </div>
          <button onClick={() => setShowSettings(true)} className="p-2 rounded-lg bg-card hover:bg-muted transition-colors">
            <Settings size={20} className="text-foreground" />
          </button>
        </header>

        <div className="flex-1 p-4 space-y-3 overflow-y-auto">
          {messages.length === 0 && (
            <p className="text-center text-muted-foreground font-body py-12">Start a conversation</p>
          )}
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.sender_id === user?.id ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[75%] px-4 py-2 rounded-xl font-body ${msg.sender_id === user?.id ? "bg-primary text-primary-foreground" : "bg-card text-foreground border border-border"}`}>
                {msg.message}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {isFriend ? (
          <div className="sticky bottom-16 p-3 bg-background/90 backdrop-blur-md border-t border-border flex gap-2">
            <input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              placeholder="Type a message..."
              className="flex-1 rounded-lg border border-border bg-card px-4 py-2.5 text-foreground font-body placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <button onClick={sendMessage} className="p-2.5 rounded-lg bg-primary text-primary-foreground">
              <Send size={20} />
            </button>
          </div>
        ) : (
          <div className="sticky bottom-16 p-4 bg-background/90 backdrop-blur-md border-t border-border flex items-center justify-center gap-2 text-muted-foreground font-body text-sm">
            <Lock size={16} />
            You can only chat with mutual followers
          </div>
        )}

        {/* Settings overlay */}
        {showSettings && (
          <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex flex-col">
            <header className="flex items-center justify-between px-4 py-3 border-b border-border">
              <div className="flex items-center gap-3">
                <button onClick={() => setShowSettings(false)}>
                  <ArrowLeft size={22} className="text-foreground" />
                </button>
                <h2 className="font-display font-bold text-lg text-foreground">CHAT SETTINGS</h2>
              </div>
            </header>
            <div className="p-4 space-y-3">
              <div className="p-4 rounded-xl bg-card border border-border">
                <div className="flex items-center gap-3 mb-1">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center font-display font-bold text-primary text-lg">
                    {selectedUser.in_game_name[0]}
                  </div>
                  <div>
                    <p className="font-display font-bold text-foreground">{selectedUser.in_game_name}</p>
                    <p className="text-xs text-muted-foreground font-body">UID: {selectedUser.uid}</p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  setShowSettings(false);
                  navigate(`/player?uid=${selectedUser.uid}`);
                }}
                className="w-full flex items-center gap-3 p-4 rounded-xl bg-card border border-border hover:bg-muted transition-colors"
              >
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <User size={20} className="text-primary" />
                </div>
                <div className="text-left">
                  <p className="font-display font-bold text-foreground text-sm">VIEW PROFILE</p>
                  <p className="text-xs text-muted-foreground font-body">See this user's profile details</p>
                </div>
              </button>
              <button
                onClick={blockUser}
                className="w-full flex items-center gap-3 p-4 rounded-xl bg-card border border-border hover:bg-muted transition-colors"
              >
                <div className="w-10 h-10 rounded-full bg-destructive/20 flex items-center justify-center">
                  <ShieldBan size={20} className="text-destructive" />
                </div>
                <div className="text-left">
                  <p className="font-display font-bold text-foreground text-sm">BLOCK USER</p>
                  <p className="text-xs text-muted-foreground font-body">Block this user from chatting with you</p>
                </div>
              </button>

              <button
                onClick={deleteChat}
                className="w-full flex items-center gap-3 p-4 rounded-xl bg-card border border-border hover:bg-muted transition-colors"
              >
                <div className="w-10 h-10 rounded-full bg-destructive/20 flex items-center justify-center">
                  <Trash2 size={20} className="text-destructive" />
                </div>
                <div className="text-left">
                  <p className="font-display font-bold text-foreground text-sm">DELETE CHAT</p>
                  <p className="text-xs text-muted-foreground font-body">Delete all messages with this user</p>
                </div>
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen grid-bg pb-20">
      <header className="sticky top-0 z-40 px-4 py-3 bg-background/90 backdrop-blur-md border-b border-border">
        <h1 className="font-display font-bold text-lg text-foreground mb-3">CHAT</h1>
        <div className="relative">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or UID..."
            className="w-full rounded-lg border border-border bg-card pl-10 pr-4 py-2.5 text-foreground font-body placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
      </header>

      <div className="p-4">
        <Tabs defaultValue="friends">
          <TabsList className="grid w-full grid-cols-2 mb-3">
            <TabsTrigger value="friends" className="font-display font-bold">My Friends</TabsTrigger>
            <TabsTrigger value="all" className="font-display font-bold">All Users</TabsTrigger>
          </TabsList>
          <TabsContent value="friends" className="space-y-2">
            {friendsFiltered.length === 0 && (
              <p className="text-center py-12 text-muted-foreground font-body">
                No friends yet. Follow users and have them follow you back to chat.
              </p>
            )}
            {friendsFiltered.map((chatUser, i) => (
              <motion.button
                key={chatUser.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => setSelectedUser(chatUser)}
                className="w-full flex items-center gap-3 p-3 rounded-xl bg-card hover:bg-muted transition-colors border border-border text-left"
              >
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center font-display font-bold text-primary text-sm">
                  {chatUser.in_game_name[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-display font-bold text-foreground text-sm truncate">{chatUser.in_game_name}</p>
                  <p className="text-xs text-muted-foreground font-body truncate">UID: {chatUser.uid}</p>
                </div>
              </motion.button>
            ))}
          </TabsContent>
          <TabsContent value="all" className="space-y-2">
            {filtered.length === 0 && (
              <p className="text-center py-12 text-muted-foreground font-body">No users found</p>
            )}
            {filtered.map((chatUser, i) => {
              const isFriend = friendIds.includes(chatUser.id);
              return (
                <motion.button
                  key={chatUser.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => isFriend ? setSelectedUser(chatUser) : navigate(`/player?uid=${chatUser.uid}`)}
                  className="w-full flex items-center gap-3 p-3 rounded-xl bg-card hover:bg-muted transition-colors border border-border text-left"
                >
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center font-display font-bold text-primary text-sm">
                    {chatUser.in_game_name[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-display font-bold text-foreground text-sm truncate">{chatUser.in_game_name}</p>
                    <p className="text-xs text-muted-foreground font-body truncate">UID: {chatUser.uid}</p>
                  </div>
                  {!isFriend && <Lock size={14} className="text-muted-foreground" />}
                </motion.button>
              );
            })}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Chat;
