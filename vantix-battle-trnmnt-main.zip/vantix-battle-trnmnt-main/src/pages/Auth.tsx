import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import logo from "@/assets/logo.jpg";

const Auth = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [uid, setUid] = useState("");
  const [inGameName, setInGameName] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [loading, setLoading] = useState(false);

  // Auto-fill referral code from URL and switch to signup
  useEffect(() => {
    const ref = searchParams.get("ref");
    if (ref) {
      setReferralCode(ref.toUpperCase());
      setIsLogin(false);
    }
  }, [searchParams]);

  // Redirect if already logged in
  if (user) {
    navigate("/home", { replace: true });
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate("/home");
      } else {
        if (!uid.trim() || !inGameName.trim()) {
          toast.error("UID and In-Game Name are required");
          setLoading(false);
          return;
        }
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              uid,
              in_game_name: inGameName,
              referral_code: referralCode.trim().toUpperCase() || undefined,
            },
          },
        });
        if (error) throw error;
        toast.success("Account created! You are now logged in.");
        if (referralCode.trim()) {
          toast.success("🎁 Referral bonus ₹10 credited!");
        }
        navigate("/home");
      }
    } catch (err: any) {
      toast.error(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid-bg flex flex-col items-center justify-center p-6">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col items-center"
      >
        <img src={logo} alt="Vantix Battle" className="w-32 h-32 rounded-2xl mb-4 glow-orange" />
        <h1 className="font-display text-3xl font-bold text-gradient mb-1">VANTIX BATTLE</h1>
        <p className="text-muted-foreground font-body text-lg mb-8">
          {isLogin ? "Welcome back, warrior" : "Enter the arena"}
        </p>
      </motion.div>

      <motion.form
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.4 }}
        onSubmit={handleSubmit}
        className="w-full max-w-sm space-y-4"
      >
        <div>
          <label className="block text-sm font-semibold text-muted-foreground mb-1 font-body">Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            className="w-full rounded-lg border border-border bg-card px-4 py-3 text-foreground font-body placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-semibold text-muted-foreground mb-1 font-body">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter password"
            className="w-full rounded-lg border border-border bg-card px-4 py-3 text-foreground font-body placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            required
            minLength={6}
          />
        </div>

        {!isLogin && (
          <>
            <div>
              <label className="block text-sm font-semibold text-muted-foreground mb-1 font-body">Game UID</label>
              <input
                type="text"
                value={uid}
                onChange={(e) => setUid(e.target.value)}
                placeholder="Enter your game UID"
                className="w-full rounded-lg border border-border bg-card px-4 py-3 text-foreground font-body placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-muted-foreground mb-1 font-body">In-Game Name</label>
              <input
                type="text"
                value={inGameName}
                onChange={(e) => setInGameName(e.target.value)}
                placeholder="Enter stylish name ✨"
                className="w-full rounded-lg border border-border bg-card px-4 py-3 text-foreground font-body placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-muted-foreground mb-1 font-body">
                Referral Code <span className="text-xs text-muted-foreground font-normal">(optional)</span>
              </label>
              <input
                type="text"
                value={referralCode}
                onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                placeholder="Enter referral code"
                maxLength={20}
                className="w-full rounded-lg border border-border bg-card px-4 py-3 text-foreground font-body placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary tracking-wider"
              />
              {referralCode && (
                <p className="mt-1 text-xs text-green-400 font-body">🎁 You'll get ₹10 bonus on signup!</p>
              )}
            </div>
          </>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-lg bg-primary py-3 font-display font-bold text-primary-foreground text-lg tracking-wider hover:opacity-90 transition-opacity glow-orange disabled:opacity-50"
        >
          {loading ? "..." : isLogin ? "LOGIN" : "SIGN UP"}
        </button>

        <button
          type="button"
          onClick={() => setIsLogin(!isLogin)}
          className="w-full text-center text-sm text-muted-foreground hover:text-foreground transition-colors font-body"
        >
          {isLogin ? "Don't have an account? Sign up" : "Already have an account? Login"}
        </button>
      </motion.form>
    </div>
  );
};

export default Auth;
