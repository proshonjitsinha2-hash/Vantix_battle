import { useNavigate } from "react-router-dom";
import { ArrowLeft, Mail, Gift, ExternalLink } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import { toast } from "sonner";

const Mailbox = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const queryClient = useQueryClient();
  const balance = profile?.balance ?? 0;

  const { data: mails = [] } = useQuery({
    queryKey: ["mails", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("mails")
        .select("*")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const claimMail = useMutation({
    mutationFn: async (mailId: string) => {
      const mail = mails.find((m) => m.id === mailId);
      if (!mail || mail.claimed) return;

      if (mail.money && mail.money > 0) {
        await supabase.from("profiles").update({ balance: balance + mail.money }).eq("id", user!.id);
        await supabase.from("transactions").insert({
          user_id: user!.id,
          type: "mail_reward",
          amount: mail.money,
          description: `Mail reward: ${mail.message.substring(0, 50)}`,
        });
      }
      await supabase.from("mails").update({ claimed: true }).eq("id", mailId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["mails"] });
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      toast.success("Mail claimed!");
    },
  });

  return (
    <div className="min-h-screen grid-bg pb-20">
      <header className="sticky top-0 z-40 flex items-center gap-3 px-4 py-3 bg-background/90 backdrop-blur-md border-b border-border">
        <button onClick={() => navigate("/home")} className="p-1">
          <ArrowLeft size={22} className="text-foreground" />
        </button>
        <h1 className="font-display font-bold text-lg text-gradient">MAILBOX</h1>
      </header>

      <div className="p-4">
        {mails.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground font-body">
            <Mail size={48} className="mx-auto mb-3 opacity-50" />
            <p>No mail yet</p>
          </div>
        ) : (
          <div className="space-y-3">
            {mails.map((mail) => (
              <div key={mail.id} className={`p-4 rounded-xl border ${mail.claimed ? "border-border bg-card" : "border-primary bg-primary/5"}`}>
                <p className="text-sm font-body text-foreground">{mail.message}</p>
                {mail.money && mail.money > 0 && (
                  <p className="text-xs text-primary font-display font-bold mt-2">
                    <Gift size={12} className="inline mr-1" />₹{mail.money} attached
                  </p>
                )}
                {mail.link && (
                  <a href={mail.link} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-xs text-primary mt-1 font-body">
                    <ExternalLink size={12} /> Open link
                  </a>
                )}
                {!mail.claimed && (
                  <button
                    onClick={() => claimMail.mutate(mail.id)}
                    className="mt-3 w-full rounded-lg bg-primary py-2 font-display font-bold text-sm text-primary-foreground hover:opacity-90 transition-opacity"
                  >
                    CLAIM
                  </button>
                )}
                <p className="text-[10px] text-muted-foreground mt-2 font-body">{new Date(mail.created_at).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Mailbox;
