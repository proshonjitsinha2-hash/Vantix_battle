import { useState, useRef } from "react";
import { Camera, Gift, ExternalLink, LogOut, Instagram, ScrollText, ChevronDown, ChevronUp, Send, UserCheck, UserX, Users } from "lucide-react";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import { useDailyLogin } from "@/hooks/useDailyLogin";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { LevelProgressCard } from "@/components/profile/LevelProgressCard";
import { BioSection } from "@/components/profile/BioSection";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  useFollowers,
  useFollowing,
  useFollowCounts,
  useIncomingFollowRequests,
  useRespondFollowRequest,
} from "@/hooks/useFollow";

const Profile = () => {
  const { user, signOut } = useAuth();
  const { data: profile } = useProfile();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [promoCode, setPromoCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [rulesOpen, setRulesOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Daily login XP hook
  useDailyLogin();

  const { data: counts } = useFollowCounts(user?.id);
  const { data: followers = [] } = useFollowers(user?.id);
  const { data: following = [] } = useFollowing(user?.id);
  const { data: requests = [] } = useIncomingFollowRequests();
  const respond = useRespondFollowRequest();

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setUploading(true);
    try {
      const ext = file.name.split(".").pop();
      const path = `${user.id}/avatar.${ext}`;
      const { error: uploadError } = await supabase.storage
        .from("avatars")
        .upload(path, file, { upsert: true });
      if (uploadError) throw uploadError;
      const { data: { publicUrl } } = supabase.storage.from("avatars").getPublicUrl(path);
      await supabase.from("profiles").update({ avatar_url: publicUrl }).eq("id", user.id);
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      toast.success("Profile picture updated!");
    } catch {
      toast.error("Failed to upload image");
    } finally {
      setUploading(false);
    }
  };

  const handlePromoSubmit = async () => {
    if (!promoCode.trim() || !user || !profile) return;
    setLoading(true);

    try {
      const { data: promo, error: promoError } = await supabase
        .from("promo_codes")
        .select("*")
        .eq("code", promoCode.trim().toUpperCase())
        .single();

      if (promoError || !promo) {
        toast.error("Invalid promo code");
        return;
      }

      if (new Date(promo.expires_at) < new Date()) {
        toast.error("Promo code has expired");
        return;
      }

      const { data: existing } = await supabase
        .from("promo_redemptions")
        .select("id")
        .eq("user_id", user.id)
        .eq("promo_code_id", promo.id)
        .maybeSingle();

      if (existing) {
        toast.error("You already used this promo code");
        return;
      }

      await supabase.from("promo_redemptions").insert({
        user_id: user.id,
        promo_code_id: promo.id,
      });
      await supabase.from("profiles").update({ balance: profile.balance + promo.reward }).eq("id", user.id);
      await supabase.from("transactions").insert({
        user_id: user.id,
        type: "promo_reward",
        amount: promo.reward,
        description: `Promo: ${promo.code}`,
      });

      queryClient.invalidateQueries({ queryKey: ["profile"] });
      toast.success(`₹${promo.reward} added to your wallet!`);
      setPromoCode("");
    } catch {
      toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  if (!profile) return null;

  return (
    <div className="min-h-screen grid-bg pb-20">
      <div className="px-4 pt-8 pb-6 text-center">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="relative inline-block">
          <div className="w-24 h-24 rounded-full bg-card border-2 border-primary flex items-center justify-center glow-orange overflow-hidden">
            {profile.avatar_url ? (
              <img src={profile.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="font-display font-bold text-3xl text-primary">{profile.in_game_name[0]}</span>
            )}
          </div>
          <input type="file" accept="image/*" ref={fileInputRef} onChange={handleAvatarUpload} className="hidden" />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="absolute bottom-0 right-0 p-1.5 bg-primary rounded-full text-primary-foreground disabled:opacity-50"
          >
            <Camera size={14} />
          </button>
        </motion.div>
        <h1 className="font-display font-bold text-xl text-foreground mt-3">{profile.in_game_name}</h1>
        <p className="text-sm text-muted-foreground font-body">UID: {profile.uid}</p>
        <div className="mt-4 flex items-center justify-center gap-6">
          <div className="text-center">
            <p className="font-display font-bold text-lg text-foreground">{counts?.followers ?? 0}</p>
            <p className="text-xs text-muted-foreground font-body">Followers</p>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="text-center">
            <p className="font-display font-bold text-lg text-foreground">{counts?.following ?? 0}</p>
            <p className="text-xs text-muted-foreground font-body">Following</p>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-4">
        {/* Level Progress */}
        <LevelProgressCard
          xp={profile.experience_points || 0}
          level={profile.level || 1}
          levelName={profile.level_name || "Bronze"}
        />

        {/* Bio Section */}
        <BioSection
          userId={user?.id || ""}
          currentBio={profile.bio}
          isOwner={true}
        />

        {/* Incoming follow requests */}
        {requests.length > 0 && (
          <div className="rounded-xl bg-card p-4 border border-border">
            <div className="flex items-center gap-2 mb-3">
              <Users size={18} className="text-primary" />
              <h3 className="font-display font-bold text-foreground">FOLLOW REQUESTS ({requests.length})</h3>
            </div>
            <div className="space-y-2">
              {requests.map((r: any) => (
                <div key={r.request_id} className="flex items-center gap-3 p-2 rounded-lg bg-background/50 border border-border">
                  <button
                    onClick={() => navigate(`/player?uid=${r.uid}`)}
                    className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center font-display font-bold text-primary text-sm overflow-hidden shrink-0"
                  >
                    {r.avatar_url ? <img src={r.avatar_url} alt="" className="w-full h-full object-cover" /> : (r.in_game_name?.[0] || "?")}
                  </button>
                  <div className="flex-1 min-w-0">
                    <p className="font-display font-bold text-sm text-foreground truncate">{r.in_game_name}</p>
                    <p className="text-xs text-muted-foreground font-body truncate">UID: {r.uid}</p>
                  </div>
                  <button
                    onClick={() => respond.mutate({ requestId: r.request_id, accept: true })}
                    disabled={respond.isPending}
                    className="p-2 rounded-lg bg-primary text-primary-foreground hover:opacity-90"
                    aria-label="Accept"
                  >
                    <UserCheck size={16} />
                  </button>
                  <button
                    onClick={() => respond.mutate({ requestId: r.request_id, accept: false })}
                    disabled={respond.isPending}
                    className="p-2 rounded-lg bg-card border border-border text-destructive hover:bg-muted"
                    aria-label="Reject"
                  >
                    <UserX size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Followers / Following tabs */}
        <div className="rounded-xl bg-card p-4 border border-border">
          <Tabs defaultValue="followers">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="followers" className="font-display font-bold">Followers</TabsTrigger>
              <TabsTrigger value="following" className="font-display font-bold">Following</TabsTrigger>
            </TabsList>
            <TabsContent value="followers" className="space-y-2 mt-3">
              {followers.length === 0 && (
                <p className="text-center text-sm text-muted-foreground font-body py-6">No followers yet</p>
              )}
              {followers.map((p: any) => (
                <button
                  key={p.id}
                  onClick={() => navigate(`/player?uid=${p.uid}`)}
                  className="w-full flex items-center gap-3 p-2 rounded-lg bg-background/50 border border-border hover:bg-muted transition-colors text-left"
                >
                  <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center font-display font-bold text-primary text-sm overflow-hidden shrink-0">
                    {p.avatar_url ? <img src={p.avatar_url} alt="" className="w-full h-full object-cover" /> : (p.in_game_name?.[0] || "?")}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-display font-bold text-sm text-foreground truncate">{p.in_game_name}</p>
                    <p className="text-xs text-muted-foreground font-body truncate">UID: {p.uid}</p>
                  </div>
                </button>
              ))}
            </TabsContent>
            <TabsContent value="following" className="space-y-2 mt-3">
              {following.length === 0 && (
                <p className="text-center text-sm text-muted-foreground font-body py-6">Not following anyone yet</p>
              )}
              {following.map((p: any) => (
                <button
                  key={p.id}
                  onClick={() => navigate(`/player?uid=${p.uid}`)}
                  className="w-full flex items-center gap-3 p-2 rounded-lg bg-background/50 border border-border hover:bg-muted transition-colors text-left"
                >
                  <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center font-display font-bold text-primary text-sm overflow-hidden shrink-0">
                    {p.avatar_url ? <img src={p.avatar_url} alt="" className="w-full h-full object-cover" /> : (p.in_game_name?.[0] || "?")}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-display font-bold text-sm text-foreground truncate">{p.in_game_name}</p>
                    <p className="text-xs text-muted-foreground font-body truncate">UID: {p.uid}</p>
                  </div>
                </button>
              ))}
            </TabsContent>
          </Tabs>
        </div>

        {/* Promo Code */}
        <div className="rounded-xl bg-card p-4 border border-border">
          <div className="flex items-center gap-2 mb-3">
            <Gift size={20} className="text-primary" />
            <h3 className="font-display font-bold text-foreground">PROMO CODE</h3>
          </div>
          <div className="flex gap-2">
            <input
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
              placeholder="Enter promo code"
              className="flex-1 rounded-lg border border-border bg-background px-3 py-2 text-foreground font-body placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-sm"
            />
            <button
              onClick={handlePromoSubmit}
              disabled={loading}
              className="px-4 rounded-lg bg-primary font-display font-bold text-sm text-primary-foreground hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              APPLY
            </button>
          </div>
          <p className="mt-3 text-xs text-muted-foreground font-body">
            Join our Telegram - Vantix eSports for promo codes
          </p>
        </div>

        {/* Instagram */}
        <a
          href="https://www.instagram.com/wlt.xeditz?igsh=anFkbTBiY2tyeXls"
          target="_blank"
          rel="noopener noreferrer"
          className="w-full rounded-xl bg-card p-4 border border-border flex items-center gap-3 hover:bg-muted transition-colors"
        >
          <Instagram size={20} className="text-pink-500" />
          <span className="font-display font-bold text-foreground">INSTAGRAM</span>
          <ExternalLink size={14} className="ml-auto text-muted-foreground" />
        </a>

        {/* Telegram */}
        <a
          href="https://t.me/VantixeSports"
          target="_blank"
          rel="noopener noreferrer"
          className="w-full rounded-xl bg-card p-4 border border-border flex items-center gap-3 hover:bg-muted transition-colors"
        >
          <Send size={20} className="text-sky-400" />
          <span className="font-display font-bold text-foreground">TELEGRAM</span>
          <ExternalLink size={14} className="ml-auto text-muted-foreground" />
        </a>

        {/* Rules and Regulations */}
        <div className="rounded-xl bg-card border border-border overflow-hidden">
          <button
            onClick={() => setRulesOpen(!rulesOpen)}
            className="w-full p-4 flex items-center gap-3 hover:bg-muted transition-colors"
          >
            <ScrollText size={20} className="text-primary" />
            <span className="font-display font-bold text-foreground">RULES & REGULATIONS</span>
            {rulesOpen ? <ChevronUp size={18} className="ml-auto text-muted-foreground" /> : <ChevronDown size={18} className="ml-auto text-muted-foreground" />}
          </button>
          {rulesOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="px-4 pb-4 space-y-4"
            >
              <div className="space-y-2">
                <h4 className="font-display font-bold text-sm text-primary">English</h4>
                <ol className="space-y-1.5 text-sm font-body">
                  <li className="text-red-400">1. Respect all players and organizers at all times.</li>
                  <li className="text-yellow-400">2. Join your match on time or risk disqualification.</li>
                  <li className="text-green-400">3. Follow the official tournament rules and format.</li>
                  <li className="text-blue-400">4. Cheating or unfair play will lead to immediate ban.</li>
                  <li className="text-purple-400">5. Organizer decisions are final and must be accepted. 🎮</li>
                </ol>
              </div>
              <div className="space-y-2">
                <h4 className="font-display font-bold text-sm text-primary">Hinglish</h4>
                <ol className="space-y-1.5 text-sm font-body">
                  <li className="text-red-400">1. Sabhi players aur organizers ka respect karein.</li>
                  <li className="text-yellow-400">2. Match time par join karein, warna disqualification ho sakta hai.</li>
                  <li className="text-green-400">3. Tournament ke official rules aur format follow karein.</li>
                  <li className="text-blue-400">4. Cheating ya unfair play karne par turant ban milega.</li>
                  <li className="text-purple-400">5. Organizer ka decision final hoga aur sabko accept karna hoga. 🎮</li>
                </ol>
              </div>
            </motion.div>
          )}
        </div>

        <button
          onClick={handleSignOut}
          className="w-full rounded-xl bg-card p-4 border border-border flex items-center gap-3 hover:bg-muted transition-colors"
        >
          <LogOut size={20} className="text-destructive" />
          <span className="font-display font-bold text-destructive">SIGN OUT</span>
        </button>
      </div>
    </div>
  );
};

export default Profile;
