export interface LevelThreshold {
  level: number;
  name: string;
  minXP: number;
  nextXP: number | null;
}

export const LEVEL_THRESHOLDS: LevelThreshold[] = [
  { level: 1, name: "Bronze", minXP: 0, nextXP: 250 },
  { level: 2, name: "Diamond", minXP: 250, nextXP: 750 },
  { level: 3, name: "Heroic", minXP: 750, nextXP: 1200 },
  { level: 5, name: "Master", minXP: 1200, nextXP: 2000 },
  { level: 10, name: "Grand Master", minXP: 2000, nextXP: null },
];

export function getLevelInfo(xp: number) {
  const reversed = [...LEVEL_THRESHOLDS].reverse();
  const current = reversed.find((t) => xp >= t.minXP) ?? LEVEL_THRESHOLDS[0];
  const currentIdx = LEVEL_THRESHOLDS.findIndex((t) => t.level === current.level);
  const next =
    currentIdx < LEVEL_THRESHOLDS.length - 1 ? LEVEL_THRESHOLDS[currentIdx + 1] : null;

  const progressXP = next ? xp - current.minXP : xp - current.minXP;
  const neededXP = next ? next.minXP - current.minXP : 1;
  const progress = next ? Math.min(100, Math.round((progressXP / neededXP) * 100)) : 100;

  return { current, next, progress, progressXP, neededXP };
}

export function getLevelColor(levelName: string): string {
  switch (levelName) {
    case "Grand Master": return "text-red-400";
    case "Master": return "text-purple-400";
    case "Heroic": return "text-orange-400";
    case "Diamond": return "text-cyan-400";
    default: return "text-yellow-500";
  }
}

export function getLevelBorderColor(levelName: string): string {
  switch (levelName) {
    case "Grand Master": return "border-red-500/60 bg-red-500/10";
    case "Master": return "border-purple-500/60 bg-purple-500/10";
    case "Heroic": return "border-orange-500/60 bg-orange-500/10";
    case "Diamond": return "border-cyan-500/60 bg-cyan-500/10";
    default: return "border-yellow-600/60 bg-yellow-600/10";
  }
}

export function getLevelBarColor(levelName: string): string {
  switch (levelName) {
    case "Grand Master": return "#ef4444";
    case "Master": return "#a855f7";
    case "Heroic": return "#f97316";
    case "Diamond": return "#06b6d4";
    default: return "#ca8a04";
  }
}

export function getLevelEmoji(levelName: string): string {
  switch (levelName) {
    case "Grand Master": return "👑";
    case "Master": return "💎";
    case "Heroic": return "🔥";
    case "Diamond": return "💠";
    default: return "🥉";
  }
}
