import { createClient } from "https://esm.sh/@supabase/supabase-js@2.98.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY")!;

    // Create user client to get user info
    const supabaseUser = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: userError } = await supabaseUser.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Service role client for admin operations
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

    const { verification_id } = await req.json();
    if (!verification_id) {
      return new Response(JSON.stringify({ error: "Missing verification_id" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Get the verification record
    const { data: verification, error: fetchError } = await supabaseAdmin
      .from("payment_verifications")
      .select("*")
      .eq("id", verification_id)
      .eq("user_id", user.id)
      .single();

    if (fetchError || !verification) {
      return new Response(JSON.stringify({ error: "Verification not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (verification.status !== "pending") {
      return new Response(JSON.stringify({ error: "Already processed", status: verification.status }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Download screenshot from storage
    const screenshotPath = verification.screenshot_url;
    const { data: fileData, error: downloadError } = await supabaseAdmin.storage
      .from("payment-screenshots")
      .download(screenshotPath);

    if (downloadError || !fileData) {
      await supabaseAdmin.from("payment_verifications").update({ status: "rejected", extracted_text: "Failed to download screenshot" }).eq("id", verification_id);
      return new Response(JSON.stringify({ error: "Failed to download screenshot", status: "rejected" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Convert to base64
    const arrayBuffer = await fileData.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    let binary = "";
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64Image = btoa(binary);
    const mimeType = fileData.type || "image/jpeg";

    // Use Lovable AI (Gemini) to analyze the screenshot
    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${lovableApiKey}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `Analyze this UPI payment screenshot carefully. Extract the following information and return ONLY a valid JSON object (no markdown, no code blocks):

{
  "receiver_name": "exact receiver/paid to name as shown",
  "transaction_id": "transaction/UTR/reference number if visible",
  "transaction_time": "date and time of transaction if visible",
  "amount": "amount paid as number only",
  "is_success": true/false (whether payment was successful),
  "is_likely_edited": true/false (if screenshot shows signs of editing like misaligned text, inconsistent fonts, artifacts),
  "missing_details": true/false (if critical details like receiver name or amount are missing),
  "confidence": "high/medium/low"
}

Be very precise with the receiver name - extract it exactly as shown. If any field is not visible, use null.`,
              },
              {
                type: "image_url",
                image_url: { url: `data:${mimeType};base64,${base64Image}` },
              },
            ],
          },
        ],
        max_tokens: 1000,
      }),
    });

    if (!aiResponse.ok) {
      const errText = await aiResponse.text();
      console.error("AI Gateway error:", errText);
      await supabaseAdmin.from("payment_verifications").update({ status: "rejected", extracted_text: "AI analysis failed" }).eq("id", verification_id);
      return new Response(JSON.stringify({ error: "AI analysis failed", status: "rejected" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const aiResult = await aiResponse.json();
    const aiText = aiResult.choices?.[0]?.message?.content || "";
    console.log("AI extracted:", aiText);

    // Parse AI response
    let parsed;
    try {
      // Try to extract JSON from the response
      const jsonMatch = aiText.match(/\{[\s\S]*\}/);
      parsed = JSON.parse(jsonMatch ? jsonMatch[0] : aiText);
    } catch {
      await supabaseAdmin.from("payment_verifications").update({ status: "rejected", extracted_text: aiText }).eq("id", verification_id);
      return new Response(JSON.stringify({ error: "Could not parse payment details", status: "rejected", extracted_text: aiText }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const receiverName = (parsed.receiver_name || "").trim();
    const transactionId = parsed.transaction_id || null;
    const transactionTime = parsed.transaction_time || null;
    const extractedAmount = parsed.amount ? Number(parsed.amount) : null;
    const isEdited = parsed.is_likely_edited === true;
    const missingDetails = parsed.missing_details === true;
    const isSuccess = parsed.is_success === true;

    // Fraud checks
    if (isEdited) {
      await supabaseAdmin.from("payment_verifications").update({
        status: "rejected", extracted_text: aiText, receiver_name: receiverName,
        transaction_id: transactionId, transaction_time: transactionTime,
      }).eq("id", verification_id);
      return new Response(JSON.stringify({ error: "Screenshot appears to be edited", status: "rejected" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (missingDetails) {
      await supabaseAdmin.from("payment_verifications").update({
        status: "rejected", extracted_text: aiText, receiver_name: receiverName,
        transaction_id: transactionId, transaction_time: transactionTime,
      }).eq("id", verification_id);
      return new Response(JSON.stringify({ error: "Screenshot is missing critical transaction details", status: "rejected" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (!isSuccess) {
      await supabaseAdmin.from("payment_verifications").update({
        status: "rejected", extracted_text: aiText, receiver_name: receiverName,
        transaction_id: transactionId, transaction_time: transactionTime,
      }).eq("id", verification_id);
      return new Response(JSON.stringify({ error: "Payment does not appear successful", status: "rejected" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Check duplicate transaction ID
    if (transactionId) {
      const { data: existing } = await supabaseAdmin
        .from("payment_verifications")
        .select("id")
        .eq("transaction_id", transactionId)
        .eq("status", "verified")
        .neq("id", verification_id)
        .limit(1);

      if (existing && existing.length > 0) {
        await supabaseAdmin.from("payment_verifications").update({
          status: "rejected", extracted_text: aiText, receiver_name: receiverName,
          transaction_id: transactionId, transaction_time: transactionTime,
        }).eq("id", verification_id);
        return new Response(JSON.stringify({ error: "Duplicate transaction ID detected", status: "rejected" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
    }

    // Verify receiver name matches "Kartik Sena Singha"
    const expectedName = "kartik sena singha";
    const nameMatch = receiverName.toLowerCase().includes(expectedName) || 
                      expectedName.includes(receiverName.toLowerCase());

    if (!nameMatch || receiverName.length < 3) {
      await supabaseAdmin.from("payment_verifications").update({
        status: "rejected", extracted_text: aiText, receiver_name: receiverName,
        transaction_id: transactionId, transaction_time: transactionTime,
      }).eq("id", verification_id);
      return new Response(JSON.stringify({ 
        error: `Receiver name "${receiverName}" does not match expected name`, 
        status: "rejected" 
      }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Amount verification
    if (extractedAmount && extractedAmount !== verification.amount) {
      await supabaseAdmin.from("payment_verifications").update({
        status: "rejected", extracted_text: aiText, receiver_name: receiverName,
        transaction_id: transactionId, transaction_time: transactionTime,
      }).eq("id", verification_id);
      return new Response(JSON.stringify({ 
        error: `Amount mismatch: expected ₹${verification.amount}, found ₹${extractedAmount}`, 
        status: "rejected" 
      }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // All checks passed - verify and credit
    await supabaseAdmin.from("payment_verifications").update({
      status: "verified", extracted_text: aiText, receiver_name: receiverName,
      transaction_id: transactionId, transaction_time: transactionTime,
    }).eq("id", verification_id);

    // Credit user balance
    const { data: profile } = await supabaseAdmin
      .from("profiles")
      .select("balance")
      .eq("id", user.id)
      .single();

    if (profile) {
      await supabaseAdmin
        .from("profiles")
        .update({ balance: profile.balance + verification.amount })
        .eq("id", user.id);
    }

    // Add transaction record
    await supabaseAdmin.from("transactions").insert({
      user_id: user.id,
      type: "upi_topup",
      amount: verification.amount,
      description: `UPI Payment verified (TXN: ${transactionId || "N/A"})`,
    });

    return new Response(JSON.stringify({ 
      status: "verified", 
      message: `₹${verification.amount} added to your wallet!`,
      receiver_name: receiverName,
      transaction_id: transactionId,
    }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: "Internal server error" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
