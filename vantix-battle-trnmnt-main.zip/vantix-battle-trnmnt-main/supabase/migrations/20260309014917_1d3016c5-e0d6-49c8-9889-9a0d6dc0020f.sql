-- Fix record_daily_login function to use proper bigint variable for ROW_COUNT
CREATE OR REPLACE FUNCTION public.record_daily_login(_user_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  row_count_val BIGINT := 0;
BEGIN
  INSERT INTO daily_logins (user_id, login_date)
  VALUES (_user_id, CURRENT_DATE)
  ON CONFLICT (user_id, login_date) DO NOTHING;

  GET DIAGNOSTICS row_count_val = ROW_COUNT;

  IF row_count_val > 0 THEN
    PERFORM award_xp(_user_id, 5, 'Daily Login');
    RETURN TRUE;
  END IF;

  RETURN FALSE;
END;
$function$;