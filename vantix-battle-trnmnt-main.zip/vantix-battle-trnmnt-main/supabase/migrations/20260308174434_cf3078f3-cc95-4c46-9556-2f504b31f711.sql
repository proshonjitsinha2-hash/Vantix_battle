
CREATE TABLE public.notices (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  text text NOT NULL DEFAULT '',
  active boolean NOT NULL DEFAULT true,
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.notices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read notices" ON public.notices FOR SELECT USING (true);
CREATE POLICY "Admins update notices" ON public.notices FOR UPDATE USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins insert notices" ON public.notices FOR INSERT WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins delete notices" ON public.notices FOR DELETE USING (has_role(auth.uid(), 'admin'::app_role));

INSERT INTO public.notices (text, active) VALUES ('HOME NOTICE', true);
