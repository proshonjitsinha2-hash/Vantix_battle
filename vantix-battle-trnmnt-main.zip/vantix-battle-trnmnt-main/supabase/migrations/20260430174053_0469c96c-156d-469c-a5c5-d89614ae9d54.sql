-- 1. follow_requests table
CREATE TABLE public.follow_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  requester_id UUID NOT NULL,
  target_id UUID NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT follow_requests_no_self CHECK (requester_id <> target_id),
  CONSTRAINT follow_requests_status_chk CHECK (status IN ('pending','accepted','rejected'))
);

CREATE UNIQUE INDEX follow_requests_unique_pending
  ON public.follow_requests (requester_id, target_id)
  WHERE status = 'pending';

CREATE INDEX idx_follow_requests_target ON public.follow_requests(target_id);
CREATE INDEX idx_follow_requests_requester ON public.follow_requests(requester_id);

ALTER TABLE public.follow_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own follow requests"
  ON public.follow_requests FOR SELECT TO authenticated
  USING (requester_id = auth.uid() OR target_id = auth.uid());

CREATE POLICY "Users send follow requests"
  ON public.follow_requests FOR INSERT TO authenticated
  WITH CHECK (requester_id = auth.uid() AND status = 'pending');

CREATE POLICY "Target updates follow requests"
  ON public.follow_requests FOR UPDATE TO authenticated
  USING (target_id = auth.uid())
  WITH CHECK (target_id = auth.uid());

CREATE POLICY "Requester cancels follow requests"
  ON public.follow_requests FOR DELETE TO authenticated
  USING (requester_id = auth.uid());

-- 2. follows table
CREATE TABLE public.follows (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  follower_id UUID NOT NULL,
  following_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT follows_no_self CHECK (follower_id <> following_id),
  CONSTRAINT follows_unique UNIQUE (follower_id, following_id)
);

CREATE INDEX idx_follows_follower ON public.follows(follower_id);
CREATE INDEX idx_follows_following ON public.follows(following_id);

ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read follows"
  ON public.follows FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Users unfollow (delete own follow)"
  ON public.follows FOR DELETE TO authenticated
  USING (follower_id = auth.uid());

-- 3. Trigger: when a follow_request is accepted, create the follow row
CREATE OR REPLACE FUNCTION public.handle_follow_request_accept()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status = 'accepted' AND (OLD.status IS DISTINCT FROM 'accepted') THEN
    INSERT INTO public.follows (follower_id, following_id)
    VALUES (NEW.requester_id, NEW.target_id)
    ON CONFLICT (follower_id, following_id) DO NOTHING;
    NEW.updated_at := now();
  ELSIF NEW.status <> OLD.status THEN
    NEW.updated_at := now();
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_follow_request_accept
  BEFORE UPDATE ON public.follow_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_follow_request_accept();

-- 4. Helper: are A and B mutuals (each follows the other)
CREATE OR REPLACE FUNCTION public.are_mutual_followers(_a UUID, _b UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.follows WHERE follower_id = _a AND following_id = _b
  ) AND EXISTS (
    SELECT 1 FROM public.follows WHERE follower_id = _b AND following_id = _a
  );
$$;

-- 5. Restrict chat: only mutuals can send messages
DROP POLICY IF EXISTS "Users send messages" ON public.chat_messages;

CREATE POLICY "Mutuals send messages"
  ON public.chat_messages FOR INSERT TO authenticated
  WITH CHECK (
    sender_id = auth.uid()
    AND public.are_mutual_followers(auth.uid(), receiver_id)
  );