-- Create storage bucket for slider images
INSERT INTO storage.buckets (id, name, public) VALUES ('slider-images', 'slider-images', true);

-- Allow anyone to read slider images
CREATE POLICY "Public read slider images" ON storage.objects FOR SELECT USING (bucket_id = 'slider-images');

-- Allow admins to upload slider images
CREATE POLICY "Admins upload slider images" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'slider-images' AND public.has_role(auth.uid(), 'admin'));

-- Allow admins to delete slider images
CREATE POLICY "Admins delete slider images" ON storage.objects FOR DELETE USING (bucket_id = 'slider-images' AND public.has_role(auth.uid(), 'admin'));