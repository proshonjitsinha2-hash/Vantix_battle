
CREATE TABLE public.chat_blocks (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  blocker_id uuid NOT NULL,
  blocked_id uuid NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(blocker_id, blocked_id)
);

ALTER TABLE public.chat_blocks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own blocks" ON public.chat_blocks FOR SELECT USING (blocker_id = auth.uid() OR blocked_id = auth.uid());
CREATE POLICY "Users insert own blocks" ON public.chat_blocks FOR INSERT WITH CHECK (blocker_id = auth.uid());
CREATE POLICY "Users delete own blocks" ON public.chat_blocks FOR DELETE USING (blocker_id = auth.uid());
