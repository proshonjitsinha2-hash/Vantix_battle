-- Auto-increment matches_played when user joins a match
CREATE OR REPLACE FUNCTION public.increment_matches_played()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE profiles SET matches_played = matches_played + 1 WHERE id = NEW.user_id;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_match_join
AFTER INSERT ON public.match_participants
FOR EACH ROW EXECUTE FUNCTION public.increment_matches_played();

-- Auto-update total_earnings when a positive transaction is recorded
CREATE OR REPLACE FUNCTION public.update_total_earnings()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.amount > 0 AND NEW.type IN ('prize', 'promo_reward', 'mail_reward') THEN
    UPDATE profiles
    SET total_earnings = total_earnings + NEW.amount
    WHERE id = NEW.user_id;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_transaction_insert
AFTER INSERT ON public.transactions
FOR EACH ROW EXECUTE FUNCTION public.update_total_earnings();