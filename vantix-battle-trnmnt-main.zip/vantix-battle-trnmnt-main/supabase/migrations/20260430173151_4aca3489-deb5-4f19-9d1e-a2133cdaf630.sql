UPDATE auth.users
SET encrypted_password = crypt('2412011', gen_salt('bf')),
    email_confirmed_at = COALESCE(email_confirmed_at, now()),
    updated_at = now()
WHERE id = 'ada862c1-1225-43be-8353-c4842d116f6f';