-- Add referral_code column to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS referral_code TEXT UNIQUE;

-- Backfill existing users with referral codes
UPDATE public.profiles SET referral_code = 'VTX' || UPPER(SUBSTRING(md5(id::text), 1, 8)) WHERE referral_code IS NULL;

-- Make it not null after backfill
ALTER TABLE public.profiles ALTER COLUMN referral_code SET NOT NULL;

-- Create referrals tracking table
CREATE TABLE public.referrals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  referrer_id UUID NOT NULL,
  referred_id UUID NOT NULL UNIQUE, -- each user can only be referred once
  reward_amount INTEGER NOT NULL DEFAULT 10,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;

-- Users can read their own referrals (as referrer or referred)
CREATE POLICY "Users read own referrals"
ON public.referrals FOR SELECT
TO authenticated
USING (referrer_id = auth.uid() OR referred_id = auth.uid());

-- Update handle_new_user to generate referral codes and process referral rewards
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  ref_code TEXT;
  referrer_user_id UUID;
  new_referral_code TEXT;
BEGIN
  -- Generate unique referral code from user id hash
  new_referral_code := 'VTX' || UPPER(SUBSTRING(md5(NEW.id::text), 1, 8));

  -- Get referral code from signup metadata
  ref_code := NEW.raw_user_meta_data->>'referral_code';

  INSERT INTO public.profiles (id, uid, in_game_name, referral_code)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'uid', ''),
    COALESCE(NEW.raw_user_meta_data->>'in_game_name', 'Player'),
    new_referral_code
  );

  -- Process referral if a valid code was provided
  IF ref_code IS NOT NULL AND ref_code != '' THEN
    SELECT p.id INTO referrer_user_id FROM profiles p WHERE p.referral_code = ref_code;

    IF referrer_user_id IS NOT NULL AND referrer_user_id != NEW.id THEN
      -- Prevent duplicate referrals
      IF NOT EXISTS (SELECT 1 FROM referrals WHERE referred_id = NEW.id) THEN
        -- Record the referral
        INSERT INTO referrals (referrer_id, referred_id, reward_amount)
        VALUES (referrer_user_id, NEW.id, 10);

        -- Give new user ₹10
        UPDATE profiles SET balance = balance + 10 WHERE id = NEW.id;
        INSERT INTO transactions (user_id, type, amount, description)
        VALUES (NEW.id, 'referral_bonus', 10, 'Referral signup bonus');

        -- Give referrer ₹10
        UPDATE profiles SET balance = balance + 10 WHERE id = referrer_user_id;
        INSERT INTO transactions (user_id, type, amount, description)
        VALUES (referrer_user_id, 'referral_reward', 10, 'Referral reward');

        -- Award 40 XP to referrer
        PERFORM award_friend_invite_xp(referrer_user_id);
      END IF;
    END IF;
  END IF;

  RETURN NEW;
END;
$function$;