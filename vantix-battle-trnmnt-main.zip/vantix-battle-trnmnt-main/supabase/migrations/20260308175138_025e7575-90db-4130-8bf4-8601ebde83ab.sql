
CREATE POLICY "Users delete own sent messages" ON public.chat_messages FOR DELETE USING (sender_id = auth.uid());
