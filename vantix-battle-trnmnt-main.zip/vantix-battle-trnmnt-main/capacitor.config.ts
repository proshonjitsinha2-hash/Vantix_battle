import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.38a6e737916547e98e59400370addf45',
  appName: 'vantix-battle-trnmnt',
  webDir: 'dist',
  server: {
    url: 'https://38a6e737-9165-47e9-8e59-400370addf45.lovableproject.com?forceHideBadge=true',
    cleartext: true,
  },
};

export default config;
